using System;
using System.Collections.Generic;
using System.Linq;

namespace Spark.DependencyExplorer
{
    internal static class DependencyGraphAnalyzer
    {
        public static IReadOnlyCollection<string> FindSharedDependencies(
            IEnumerable<string> candidates,
            IEnumerable<string> sourceAssets,
            IEnumerable<string> allProjectAssets,
            Func<string, IEnumerable<string>> getDirectDependencies,
            CancelableProgress progress = null)
        {
            var candidateSet = new HashSet<string>(candidates, StringComparer.OrdinalIgnoreCase);
            var sourceSet = new HashSet<string>(sourceAssets, StringComparer.OrdinalIgnoreCase);
            var allAssets = allProjectAssets
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderBy(path => path, StringComparer.OrdinalIgnoreCase)
                .ToArray();
            var shared = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            for (int i = 0; i < allAssets.Length; i++)
            {
                string asset = allAssets[i];
                if (sourceSet.Contains(asset) || candidateSet.Contains(asset))
                {
                    continue;
                }

                if (progress != null && progress(new ScanProgress(
                        "正在检查共享依赖",
                        asset,
                        allAssets.Length == 0 ? 1f : (float)i / allAssets.Length)))
                {
                    throw new OperationCanceledException("共享依赖检查已取消。");
                }

                foreach (string dependency in getDirectDependencies(asset))
                {
                    if (candidateSet.Contains(dependency))
                    {
                        shared.Add(dependency);
                    }
                }
            }

            // A shared candidate keeps its own candidate dependencies alive as well.
            var queue = new Queue<string>(shared);
            while (queue.Count > 0)
            {
                string sharedAsset = queue.Dequeue();
                foreach (string dependency in getDirectDependencies(sharedAsset))
                {
                    if (candidateSet.Contains(dependency) && shared.Add(dependency))
                    {
                        queue.Enqueue(dependency);
                    }
                }
            }

            return shared;
        }
    }
}
