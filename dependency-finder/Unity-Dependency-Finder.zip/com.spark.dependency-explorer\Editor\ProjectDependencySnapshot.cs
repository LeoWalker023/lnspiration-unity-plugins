using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;

namespace Spark.DependencyExplorer
{
    internal sealed class ProjectDependencySnapshot
    {
        private readonly Dictionary<string, string[]> _directDependencies;
        private readonly ReverseReferenceGraph _reverseReferences;

        private ProjectDependencySnapshot(
            IReadOnlyList<string> allAssets,
            Dictionary<string, string[]> directDependencies)
        {
            AllAssets = allAssets;
            _directDependencies = directDependencies;
            _reverseReferences = new ReverseReferenceGraph(directDependencies);
        }

        public IReadOnlyList<string> AllAssets { get; }

        public IEnumerable<string> GetDirectDependencies(string assetPath)
        {
            return _directDependencies.TryGetValue(assetPath, out string[] dependencies)
                ? dependencies
                : Array.Empty<string>();
        }

        public IReadOnlyList<string> GetReferences(IEnumerable<string> targetPaths, bool recursive)
        {
            return _reverseReferences.GetReferences(targetPaths, recursive);
        }

        public static ProjectDependencySnapshot Capture(CancelableProgress progress = null)
        {
            string[] allAssets = AssetDatabase.FindAssets(string.Empty, new[] { "Assets" })
                .Select(AssetDatabase.GUIDToAssetPath)
                .Select(AssetPathUtility.Normalize)
                .Where(path => !string.IsNullOrEmpty(path) && !AssetDatabase.IsValidFolder(path))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderBy(path => path, StringComparer.OrdinalIgnoreCase)
                .ToArray();
            var dependencies = new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase);

            for (int i = 0; i < allAssets.Length; i++)
            {
                string assetPath = allAssets[i];
                if (progress != null && progress(new ScanProgress(
                        "正在建立项目引用索引",
                        assetPath,
                        allAssets.Length == 0 ? 1f : (float)i / allAssets.Length)))
                {
                    throw new OperationCanceledException("项目引用索引已取消。");
                }

                try
                {
                    dependencies[assetPath] = DependencyScanService
                        .GetDependenciesForAsset(assetPath, false)
                        .ToArray();
                }
                catch
                {
                    dependencies[assetPath] = Array.Empty<string>();
                }
            }

            return new ProjectDependencySnapshot(allAssets, dependencies);
        }
    }
}
