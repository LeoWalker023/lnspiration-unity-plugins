using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

namespace Spark.DependencyExplorer
{
    internal sealed class DependencyExplorerWindow : EditorWindow
    {
        private const float SourcePaneRatio = 0.56f;
        private const float SourceRowHeight = 52f;
        private const float DependencyRowHeight = 52f;
        private const float ImageDependencyRowHeight = 68f;

        private static readonly Color CanvasColor = new Color(0.066f, 0.075f, 0.086f);
        private static readonly Color HeaderColor = new Color(0.082f, 0.094f, 0.106f);
        private static readonly Color PanelColor = new Color(0.096f, 0.110f, 0.125f);
        private static readonly Color RaisedColor = new Color(0.119f, 0.137f, 0.154f);
        private static readonly Color HoverColor = new Color(0.145f, 0.169f, 0.188f);
        private static readonly Color SelectedColor = new Color(0.075f, 0.188f, 0.184f);
        private static readonly Color BorderColor = new Color(0.188f, 0.216f, 0.239f);
        private static readonly Color AccentColor = new Color(0.169f, 0.718f, 0.635f);
        private static readonly Color TextColor = new Color(0.906f, 0.933f, 0.949f);
        private static readonly Color MutedTextColor = new Color(0.535f, 0.600f, 0.647f);
        private static readonly Color DangerColor = new Color(0.788f, 0.275f, 0.310f);
        private static readonly Color DangerHoverColor = new Color(0.882f, 0.329f, 0.357f);

        private readonly List<string> _inputPaths = new List<string>();
        private readonly HashSet<string> _selectedSourceAssets = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private readonly HashSet<string> _selectedDependencyAssets = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private readonly HashSet<string> _excludedDependencyAssets = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private readonly HashSet<string> _eligibleDependencyAssets = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private readonly HashSet<string> _sharedDependencyAssets = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private readonly HashSet<string> _protectedCodeAssets = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private readonly HashSet<string> _expandedFolders = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        private DependencyScanResult _scanResult;
        private ProjectDependencySnapshot _projectSnapshot;
        private CSharpReferenceSnapshot _codeReferenceSnapshot;
        private Vector2 _sourceScroll;
        private Vector2 _dependencyScroll;
        private Vector2 _inputScroll;
        private string _activePath = string.Empty;
        private string _search = string.Empty;
        private bool _showRecursiveDependencies;
        private bool _showReverseReferences;
        private bool _showOnlyExternalDependencies;
        private bool _includeDependenciesOnDelete;
        private bool _protectSharedDependencies = true;
        private bool _waitingForPreviews;
        private bool _sourceListHasKeyboardFocus;
        private GUIStyle _rowButtonStyle;
        private GUIStyle _pathStyle;
        private GUIStyle _badgeStyle;
        private GUIStyle _titleStyle;
        private GUIStyle _subtitleStyle;
        private GUIStyle _sectionTitleStyle;
        private GUIStyle _rowTitleStyle;
        private GUIStyle _countStyle;
        private GUIStyle _centerMutedStyle;
        private GUIStyle _iconButtonStyle;
        private GUIStyle _secondaryButtonStyle;
        private GUIStyle _dangerButtonStyle;
        private GUIStyle _chipStyle;
        private GUIStyle _segmentStyle;
        private GUIStyle _segmentActiveStyle;
        private GUIStyle _searchStyle;
        private GUIStyle _panelStyle;
        private GUIStyle _checkStyle;
        private Texture2D _raisedTexture;
        private Texture2D _hoverTexture;
        private Texture2D _selectedTexture;
        private Texture2D _dangerTexture;
        private Texture2D _dangerHoverTexture;
        private Texture2D _panelTexture;

        [MenuItem("Tools/Spark/依赖检索器")]
        private static void Open()
        {
            var window = GetWindow<DependencyExplorerWindow>();
            window.titleContent = new GUIContent("依赖检索器");
            window.minSize = new Vector2(980f, 620f);
            window.Show();
        }

        private void OnEnable()
        {
            titleContent = new GUIContent("依赖检索器");
        }

        private void OnDisable()
        {
            DestroyStyleTexture(ref _raisedTexture);
            DestroyStyleTexture(ref _hoverTexture);
            DestroyStyleTexture(ref _selectedTexture);
            DestroyStyleTexture(ref _dangerTexture);
            DestroyStyleTexture(ref _dangerHoverTexture);
            DestroyStyleTexture(ref _panelTexture);
        }

        private void OnInspectorUpdate()
        {
            if (_waitingForPreviews)
            {
                Repaint();
            }
        }

        private void OnGUI()
        {
            EnsureStyles();
            HandleSourceKeyboardNavigation(Event.current);
            _waitingForPreviews = false;
            EditorGUI.DrawRect(new Rect(0f, 0f, position.width, position.height), CanvasColor);
            DrawTopToolbar();
            DrawDropArea();
            DrawInputStrip();

            if (_scanResult == null)
            {
                DrawEmptyState();
                return;
            }

            DrawWorkspace();
            DrawDeleteFooter();
        }

        private void EnsureStyles()
        {
            if (_titleStyle != null)
            {
                return;
            }

            _raisedTexture = CreateStyleTexture(RaisedColor);
            _hoverTexture = CreateStyleTexture(HoverColor);
            _selectedTexture = CreateStyleTexture(SelectedColor);
            _dangerTexture = CreateStyleTexture(DangerColor);
            _dangerHoverTexture = CreateStyleTexture(DangerHoverColor);
            _panelTexture = CreateStyleTexture(PanelColor);

            _titleStyle = new GUIStyle(EditorStyles.boldLabel)
            {
                fontSize = 16,
                normal = { textColor = TextColor }
            };

            _subtitleStyle = new GUIStyle(EditorStyles.label)
            {
                fontSize = 10,
                clipping = TextClipping.Clip,
                normal = { textColor = MutedTextColor }
            };

            _sectionTitleStyle = new GUIStyle(EditorStyles.boldLabel)
            {
                fontSize = 12,
                normal = { textColor = TextColor }
            };

            _rowTitleStyle = new GUIStyle(EditorStyles.label)
            {
                fontSize = 11,
                clipping = TextClipping.Clip,
                normal = { textColor = TextColor },
                hover = { textColor = TextColor }
            };

            _rowButtonStyle = new GUIStyle(_rowTitleStyle)
            {
                alignment = TextAnchor.MiddleLeft,
                padding = new RectOffset(0, 0, 0, 0)
            };

            _pathStyle = new GUIStyle(EditorStyles.miniLabel)
            {
                fontSize = 9,
                clipping = TextClipping.Clip,
                normal = { textColor = MutedTextColor }
            };

            _badgeStyle = new GUIStyle(EditorStyles.miniLabel)
            {
                alignment = TextAnchor.MiddleCenter,
                clipping = TextClipping.Clip,
                fontSize = 9,
                normal = { textColor = TextColor }
            };

            _countStyle = new GUIStyle(_badgeStyle)
            {
                fontSize = 10,
                normal = { textColor = AccentColor }
            };

            _centerMutedStyle = new GUIStyle(_subtitleStyle)
            {
                alignment = TextAnchor.MiddleCenter,
                fontSize = 11
            };

            _iconButtonStyle = CreateButtonStyle(_raisedTexture, _hoverTexture, 0, TextAnchor.MiddleCenter);
            _secondaryButtonStyle = CreateButtonStyle(_raisedTexture, _hoverTexture, 8, TextAnchor.MiddleCenter);
            _dangerButtonStyle = CreateButtonStyle(_dangerTexture, _dangerHoverTexture, 10, TextAnchor.MiddleCenter);
            _dangerButtonStyle.fontStyle = FontStyle.Bold;
            _chipStyle = CreateButtonStyle(_raisedTexture, _hoverTexture, 8, TextAnchor.MiddleCenter);
            _chipStyle.fontSize = 10;
            _segmentStyle = CreateButtonStyle(_raisedTexture, _hoverTexture, 8, TextAnchor.MiddleCenter);
            _segmentStyle.fontSize = 10;
            _segmentActiveStyle = CreateButtonStyle(_selectedTexture, _selectedTexture, 8, TextAnchor.MiddleCenter);
            _segmentActiveStyle.fontSize = 10;
            _segmentActiveStyle.normal.textColor = AccentColor;
            _segmentActiveStyle.hover.textColor = AccentColor;

            _searchStyle = new GUIStyle(EditorStyles.textField)
            {
                normal = { background = _raisedTexture, textColor = TextColor },
                focused = { background = _raisedTexture, textColor = TextColor },
                hover = { background = _hoverTexture, textColor = TextColor },
                padding = new RectOffset(28, 8, 5, 4),
                fontSize = 10
            };

            _panelStyle = new GUIStyle
            {
                normal = { background = _panelTexture },
                padding = new RectOffset(0, 0, 0, 0),
                margin = new RectOffset(0, 0, 0, 0)
            };

            _checkStyle = new GUIStyle(_badgeStyle)
            {
                fontSize = 11,
                fontStyle = FontStyle.Bold,
                alignment = TextAnchor.MiddleCenter,
                normal = { textColor = TextColor }
            };
        }

        private void DrawTopToolbar()
        {
            Rect header = GUILayoutUtility.GetRect(0f, 62f, GUILayout.ExpandWidth(true));
            EditorGUI.DrawRect(header, HeaderColor);
            EditorGUI.DrawRect(new Rect(header.x, header.yMax - 1f, header.width, 1f), BorderColor);

            Rect mark = new Rect(header.x + 16f, header.y + 14f, 34f, 34f);
            EditorGUI.DrawRect(mark, SelectedColor);
            GUIContent searchIcon = EditorGUIUtility.IconContent("d_Search Icon");
            if (searchIcon.image != null)
            {
                GUI.DrawTexture(new Rect(mark.x + 7f, mark.y + 7f, 20f, 20f), searchIcon.image, ScaleMode.ScaleToFit, true);
            }

            GUI.Label(new Rect(header.x + 62f, header.y + 10f, 240f, 24f), "资源依赖检索器", _titleStyle);
            GUI.Label(
                new Rect(header.x + 62f, header.y + 34f, 360f, 18f),
                "追踪资产引用，精确控制清理范围",
                _subtitleStyle);

            DrawPill(new Rect(header.xMax - 174f, header.y + 21f, 52f, 20f), "v1.1.0", AccentColor, SelectedColor);

            using (new EditorGUI.DisabledScope(_inputPaths.Count == 0))
            {
                GUIContent refresh = EditorGUIUtility.IconContent("Refresh");
                refresh.tooltip = "重新扫描";
                if (GUI.Button(new Rect(header.xMax - 108f, header.y + 15f, 36f, 32f), refresh, _iconButtonStyle))
                {
                    Scan(true);
                }
            }

            using (new EditorGUI.DisabledScope(_inputPaths.Count == 0 && _scanResult == null))
            {
                GUIContent clear = EditorGUIUtility.IconContent("TreeEditor.Trash");
                clear.tooltip = "清空";
                if (GUI.Button(new Rect(header.xMax - 60f, header.y + 15f, 36f, 32f), clear, _iconButtonStyle))
                {
                    Clear();
                }
            }
        }

        private void DrawDropArea()
        {
            Rect area = GUILayoutUtility.GetRect(0f, 88f, GUILayout.ExpandWidth(true));
            Rect dropRect = new Rect(area.x + 14f, area.y + 11f, area.width - 28f, 66f);
            bool dragActive = dropRect.Contains(Event.current.mousePosition)
                && (Event.current.type == EventType.DragUpdated || Event.current.type == EventType.DragPerform);
            EditorGUI.DrawRect(dropRect, dragActive ? SelectedColor : PanelColor);
            DrawBorder(dropRect, dragActive ? AccentColor : BorderColor);

            Rect dropIcon = new Rect(dropRect.x + 16f, dropRect.y + 16f, 34f, 34f);
            EditorGUI.DrawRect(dropIcon, RaisedColor);
            Texture folderIcon = EditorGUIUtility.IconContent("Folder Icon").image;
            if (folderIcon != null)
            {
                GUI.DrawTexture(new Rect(dropIcon.x + 6f, dropIcon.y + 6f, 22f, 22f), folderIcon, ScaleMode.ScaleToFit, true);
            }

            GUI.Label(
                new Rect(dropRect.x + 64f, dropRect.y + 12f, dropRect.width - 230f, 22f),
                "拖入预制体、材质、场景、文件夹或任意 Unity 资产",
                _sectionTitleStyle);
            GUI.Label(
                new Rect(dropRect.x + 64f, dropRect.y + 35f, dropRect.width - 230f, 18f),
                "松开后自动扫描直接引用与递归引用",
                _subtitleStyle);

            Rect addRect = new Rect(dropRect.xMax - 132f, dropRect.y + 16f, 116f, 34f);
            GUIContent addContent = EditorGUIUtility.IconContent("Folder Icon");
            addContent.text = " 添加文件夹";
            addContent.tooltip = "选择 Assets 下的文件夹";
            if (GUI.Button(addRect, addContent, _secondaryButtonStyle))
            {
                AddFolderFromDialog();
            }

            HandleDragAndDrop(dropRect);
        }

        private void DrawInputStrip()
        {
            if (_inputPaths.Count == 0)
            {
                return;
            }

            Rect strip = GUILayoutUtility.GetRect(0f, 36f, GUILayout.ExpandWidth(true));
            EditorGUI.DrawRect(strip, HeaderColor);
            float contentWidth = 14f;
            foreach (string inputPath in _inputPaths)
            {
                GUIContent measure = new GUIContent(" " + Path.GetFileName(inputPath) + "  × ", AssetDatabase.GetCachedIcon(inputPath));
                contentWidth += Mathf.Clamp(_chipStyle.CalcSize(measure).x, 90f, 210f) + 8f;
            }

            Rect viewport = new Rect(strip.x, strip.y, strip.width, strip.height);
            Rect contentRect = new Rect(0f, 0f, Mathf.Max(strip.width, contentWidth), strip.height - 2f);
            _inputScroll = GUI.BeginScrollView(viewport, _inputScroll, contentRect, false, false);
            float x = 14f;
            string removedPath = null;
            foreach (string inputPath in _inputPaths.ToArray())
            {
                GUIContent content = new GUIContent(
                    " " + Path.GetFileName(inputPath) + "  × ",
                    AssetDatabase.GetCachedIcon(inputPath),
                    inputPath + "\n点击移除");
                float width = Mathf.Clamp(_chipStyle.CalcSize(content).x, 90f, 210f);
                if (GUI.Button(new Rect(x, 7f, width, 22f), content, _chipStyle))
                {
                    removedPath = inputPath;
                }
                x += width + 8f;
            }
            GUI.EndScrollView();

            if (!string.IsNullOrEmpty(removedPath))
            {
                _inputPaths.Remove(removedPath);
                _expandedFolders.Remove(removedPath);
                Scan(false);
                GUIUtility.ExitGUI();
            }
        }

        private void DrawEmptyState()
        {
            GUILayout.FlexibleSpace();
            Rect empty = GUILayoutUtility.GetRect(0f, 110f, GUILayout.ExpandWidth(true));
            Rect iconRect = new Rect(empty.center.x - 20f, empty.y + 4f, 40f, 40f);
            EditorGUI.DrawRect(iconRect, RaisedColor);
            Texture icon = EditorGUIUtility.IconContent("d_Search Icon").image;
            if (icon != null)
            {
                GUI.DrawTexture(new Rect(iconRect.x + 9f, iconRect.y + 9f, 22f, 22f), icon, ScaleMode.ScaleToFit, true);
            }
            GUI.Label(new Rect(empty.x, empty.y + 51f, empty.width, 22f), "尚未导入资产", _centerMutedStyle);
            GUI.Label(new Rect(empty.x, empty.y + 75f, empty.width, 18f), "从 Project 窗口拖入资产开始检索", _centerMutedStyle);
            GUILayout.FlexibleSpace();
        }

        private void DrawWorkspace()
        {
            float contentWidth = position.width - 38f;
            float leftWidth = Mathf.Clamp(contentWidth * SourcePaneRatio, 430f, contentWidth - 390f);
            using (new EditorGUILayout.HorizontalScope(GUILayout.ExpandHeight(true)))
            {
                GUILayout.Space(14f);
                using (new EditorGUILayout.VerticalScope(_panelStyle, GUILayout.Width(leftWidth), GUILayout.ExpandHeight(true)))
                {
                    DrawSourceHeader();
                    DrawSourceToolbar();
                    _sourceScroll = EditorGUILayout.BeginScrollView(_sourceScroll, GUILayout.ExpandHeight(true));
                    DrawSourceRows();
                    EditorGUILayout.EndScrollView();
                }

                GUILayout.Space(10f);

                using (new EditorGUILayout.VerticalScope(_panelStyle, GUILayout.ExpandWidth(true), GUILayout.ExpandHeight(true)))
                {
                    DrawDependencyHeader();
                    DrawDependencyToolbar();
                    _dependencyScroll = EditorGUILayout.BeginScrollView(_dependencyScroll, GUILayout.ExpandHeight(true));
                    DrawDependencyRows();
                    EditorGUILayout.EndScrollView();
                }
                GUILayout.Space(14f);
            }
        }

        private void DrawSourceHeader()
        {
            int deletableCount = _scanResult.Records.Count(record => AssetPathUtility.IsProjectAsset(record.AssetPath));
            int selectedCount = _selectedSourceAssets.Count;
            Rect header = GUILayoutUtility.GetRect(0f, 54f, GUILayout.ExpandWidth(true));
            EditorGUI.DrawRect(header, PanelColor);
            EditorGUI.DrawRect(new Rect(header.x, header.yMax - 1f, header.width, 1f), BorderColor);
            GUI.Label(new Rect(header.x + 14f, header.y + 8f, 160f, 20f), "导入资产", _sectionTitleStyle);
            GUI.Label(
                new Rect(header.x + 14f, header.y + 29f, 180f, 17f),
                "已选 " + selectedCount + " / " + deletableCount,
                _subtitleStyle);

            if (GUI.Button(new Rect(header.xMax - 128f, header.y + 13f, 48f, 28f), "全选", _secondaryButtonStyle))
            {
                SelectAllSources();
            }
            if (GUI.Button(new Rect(header.xMax - 72f, header.y + 13f, 60f, 28f), "取消全选", _secondaryButtonStyle))
            {
                _selectedSourceAssets.Clear();
                SourceSelectionChanged();
            }
        }

        private void DrawSourceToolbar()
        {
            Rect toolbar = GUILayoutUtility.GetRect(0f, 42f, GUILayout.ExpandWidth(true));
            EditorGUI.DrawRect(toolbar, HeaderColor);
            Rect searchRect = new Rect(toolbar.x + 10f, toolbar.y + 7f, toolbar.width - 112f, 28f);
            if (Event.current.type == EventType.MouseDown && searchRect.Contains(Event.current.mousePosition))
            {
                _sourceListHasKeyboardFocus = false;
            }
            _search = GUI.TextField(searchRect, _search, _searchStyle);
            Texture searchIcon = EditorGUIUtility.IconContent("d_Search Icon").image;
            if (searchIcon != null)
            {
                GUI.DrawTexture(new Rect(searchRect.x + 7f, searchRect.y + 6f, 16f, 16f), searchIcon, ScaleMode.ScaleToFit, true);
            }
            GUI.Label(new Rect(toolbar.xMax - 92f, toolbar.y + 12f, 80f, 18f), "层级视图", _subtitleStyle);
        }

        private void HandleSourceKeyboardNavigation(Event current)
        {
            if (!_sourceListHasKeyboardFocus || _scanResult == null || current.type != EventType.KeyDown)
            {
                return;
            }

            int direction;
            if (current.keyCode == KeyCode.UpArrow)
            {
                direction = -1;
            }
            else if (current.keyCode == KeyCode.DownArrow)
            {
                direction = 1;
            }
            else
            {
                return;
            }

            IReadOnlyList<string> visiblePaths = GetVisibleSourcePaths();
            string nextPath = SourceNavigationUtility.FindAdjacent(visiblePaths, _activePath, direction);
            if (!string.IsNullOrEmpty(nextPath))
            {
                SetActivePath(nextPath);
                ScrollSourcePathIntoView(visiblePaths, nextPath);
            }
            current.Use();
        }

        private IReadOnlyList<string> GetVisibleSourcePaths()
        {
            var paths = new List<string>();
            foreach (string inputPath in _scanResult.InputPaths)
            {
                if (AssetDatabase.IsValidFolder(inputPath))
                {
                    AssetDependencyRecord[] children = _scanResult.Records
                        .Where(record => AssetPathUtility.IsInsideFolder(record.AssetPath, inputPath))
                        .Where(RecordMatchesSearch)
                        .ToArray();
                    if (!MatchesSearch(inputPath) && children.Length == 0)
                    {
                        continue;
                    }

                    paths.Add(inputPath);
                    if (_expandedFolders.Contains(inputPath) || !string.IsNullOrWhiteSpace(_search))
                    {
                        paths.AddRange(children.Select(record => record.AssetPath));
                    }
                }
                else
                {
                    AssetDependencyRecord record = FindRecord(inputPath);
                    if (record != null && RecordMatchesSearch(record))
                    {
                        paths.Add(record.AssetPath);
                    }
                }
            }
            return paths;
        }

        private void ScrollSourcePathIntoView(IReadOnlyList<string> visiblePaths, string assetPath)
        {
            int index = visiblePaths
                .Select((path, pathIndex) => new { path, pathIndex })
                .Where(item => item.path.Equals(assetPath, StringComparison.OrdinalIgnoreCase))
                .Select(item => item.pathIndex)
                .DefaultIfEmpty(-1)
                .First();
            if (index < 0)
            {
                return;
            }

            float inputStripHeight = _inputPaths.Count > 0 ? 36f : 0f;
            float viewportHeight = Mathf.Max(
                SourceRowHeight,
                position.height - 62f - 88f - inputStripHeight - 84f - 54f - 42f);
            float rowTop = index * SourceRowHeight;
            float rowBottom = rowTop + SourceRowHeight;
            if (rowTop < _sourceScroll.y)
            {
                _sourceScroll.y = rowTop;
            }
            else if (rowBottom > _sourceScroll.y + viewportHeight)
            {
                _sourceScroll.y = rowBottom - viewportHeight;
            }
        }

        private void DrawSourceRows()
        {
            foreach (string inputPath in _scanResult.InputPaths)
            {
                if (AssetDatabase.IsValidFolder(inputPath))
                {
                    AssetDependencyRecord[] children = _scanResult.Records
                        .Where(record => AssetPathUtility.IsInsideFolder(record.AssetPath, inputPath))
                        .Where(RecordMatchesSearch)
                        .ToArray();
                    bool folderMatches = MatchesSearch(inputPath);
                    if (!folderMatches && children.Length == 0)
                    {
                        continue;
                    }

                    DrawFolderSourceRow(inputPath, children);
                    if (_expandedFolders.Contains(inputPath) || !string.IsNullOrWhiteSpace(_search))
                    {
                        foreach (AssetDependencyRecord child in children)
                        {
                            DrawAssetSourceRow(child, true);
                        }
                    }
                }
                else
                {
                    AssetDependencyRecord record = FindRecord(inputPath);
                    if (record != null && RecordMatchesSearch(record))
                    {
                        DrawAssetSourceRow(record, false);
                    }
                }
            }
        }

        private void DrawFolderSourceRow(string folderPath, IReadOnlyList<AssetDependencyRecord> visibleChildren)
        {
            AssetDependencyRecord[] allChildren = _scanResult.Records
                .Where(record => AssetPathUtility.IsInsideFolder(record.AssetPath, folderPath))
                .ToArray();
            string[] deletableChildren = allChildren
                .Select(record => record.AssetPath)
                .Where(AssetPathUtility.IsProjectAsset)
                .ToArray();
            int selectedChildren = deletableChildren.Count(_selectedSourceAssets.Contains);
            bool allSelected = deletableChildren.Length > 0 && selectedChildren == deletableChildren.Length;
            bool mixed = selectedChildren > 0 && selectedChildren < deletableChildren.Length;
            int dependencyCount = GetDependencies(allChildren).Count;
            Rect row = GUILayoutUtility.GetRect(0f, SourceRowHeight, GUILayout.ExpandWidth(true));
            row = new Rect(row.x + 6f, row.y, row.width - 12f, row.height);
            bool active = _activePath.Equals(folderPath, StringComparison.OrdinalIgnoreCase);
            DrawRowBackground(row, active);

            Rect checkRect = new Rect(row.x + 10f, row.y + 18f, 16f, 16f);
            if (DrawCheckbox(checkRect, allSelected, deletableChildren.Length > 0, mixed))
            {
                bool nextSelected = !allSelected;
                foreach (string childPath in deletableChildren)
                {
                    SetSourceSelected(childPath, nextSelected);
                }
                SourceSelectionChanged();
            }

            Rect foldoutRect = new Rect(row.x + 32f, row.y + 17f, 18f, 18f);
            bool expanded = _expandedFolders.Contains(folderPath);
            if (GUI.Button(foldoutRect, expanded ? "▾" : "▸", _badgeStyle))
            {
                if (!expanded) _expandedFolders.Add(folderPath);
                else _expandedFolders.Remove(folderPath);
            }

            Object folder = AssetDatabase.LoadMainAssetAtPath(folderPath);
            DrawMiniAssetIcon(new Rect(row.x + 54f, row.y + 14f, 24f, 24f), folderPath, folder);
            Rect mainRect = new Rect(row.x + 86f, row.y + 5f, row.width - 284f, row.height - 10f);
            if (GUI.Button(mainRect, new GUIContent(string.Empty, "查看该文件夹的引用"), GUIStyle.none))
            {
                SetActivePath(folderPath);
            }
            GUI.Label(new Rect(mainRect.x, mainRect.y + 2f, mainRect.width, 19f), Path.GetFileName(folderPath), _rowTitleStyle);
            GUI.Label(new Rect(mainRect.x, mainRect.y + 23f, mainRect.width, 16f), folderPath, _pathStyle);

            DrawPill(new Rect(row.xMax - 188f, row.y + 16f, 62f, 20f), "文件夹", MutedTextColor, RaisedColor);
            DrawPill(new Rect(row.xMax - 116f, row.y + 16f, 54f, 20f), dependencyCount + " 引用", AccentColor, SelectedColor);
            DrawLocateButton(new Rect(row.xMax - 42f, row.y + 10f, 32f, 32f), folderPath);
        }

        private void DrawAssetSourceRow(AssetDependencyRecord record, bool indented)
        {
            Rect row = GUILayoutUtility.GetRect(0f, SourceRowHeight, GUILayout.ExpandWidth(true));
            row = new Rect(row.x + 6f, row.y, row.width - 12f, row.height);
            bool active = _activePath.Equals(record.AssetPath, StringComparison.OrdinalIgnoreCase);
            DrawRowBackground(row, active);
            bool canDelete = AssetPathUtility.IsProjectAsset(record.AssetPath);
            bool selected = _selectedSourceAssets.Contains(record.AssetPath);
            Rect checkRect = new Rect(row.x + 10f, row.y + 18f, 16f, 16f);
            if (DrawCheckbox(checkRect, selected, canDelete))
            {
                SetSourceSelected(record.AssetPath, !selected);
                SourceSelectionChanged();
            }

            float indent = indented ? 20f : 0f;
            Object asset = AssetDatabase.LoadMainAssetAtPath(record.AssetPath);
            DrawMiniAssetIcon(new Rect(row.x + 36f + indent, row.y + 14f, 24f, 24f), record.AssetPath, asset);
            Rect mainRect = new Rect(row.x + 68f + indent, row.y + 5f, row.width - 266f - indent, row.height - 10f);
            if (GUI.Button(mainRect, new GUIContent(string.Empty, "查看该资产的引用"), GUIStyle.none))
            {
                SetActivePath(record.AssetPath);
            }
            GUI.Label(
                new Rect(mainRect.x, mainRect.y + 2f, mainRect.width, 19f),
                Path.GetFileName(record.AssetPath),
                _rowTitleStyle);
            GUI.Label(new Rect(mainRect.x, mainRect.y + 23f, mainRect.width, 16f), record.AssetPath, _pathStyle);

            int count = _showRecursiveDependencies ? record.RecursiveDependencies.Count : record.DirectDependencies.Count;
            DrawPill(
                new Rect(row.xMax - 188f, row.y + 16f, 62f, 20f),
                GetAssetTypeLabel(record.AssetPath),
                MutedTextColor,
                RaisedColor);
            DrawPill(new Rect(row.xMax - 116f, row.y + 16f, 54f, 20f), count + " 引用", AccentColor, SelectedColor);
            DrawLocateButton(new Rect(row.xMax - 42f, row.y + 10f, 32f, 32f), record.AssetPath);
        }

        private void DrawDependencyHeader()
        {
            Rect header = GUILayoutUtility.GetRect(0f, 54f, GUILayout.ExpandWidth(true));
            EditorGUI.DrawRect(header, PanelColor);
            EditorGUI.DrawRect(new Rect(header.x, header.yMax - 1f, header.width, 1f), BorderColor);
            GUI.Label(
                new Rect(header.x + 14f, header.y + 8f, 160f, 20f),
                _showReverseReferences ? "被引用位置" : "依赖资产",
                _sectionTitleStyle);
            GUI.Label(
                new Rect(header.x + 14f, header.y + 29f, header.width - 110f, 17f),
                string.IsNullOrEmpty(_activePath) ? "未选择来源资产" : _activePath,
                _pathStyle);
            int count = GetActiveReferenceItems().Count;
            DrawPill(new Rect(header.xMax - 68f, header.y + 16f, 54f, 22f), count + " 项", AccentColor, SelectedColor);
        }

        private void DrawDependencyToolbar()
        {
            Rect toolbar = GUILayoutUtility.GetRect(0f, 42f, GUILayout.ExpandWidth(true));
            EditorGUI.DrawRect(toolbar, HeaderColor);
            Rect forwardRect = new Rect(toolbar.x + 10f, toolbar.y + 7f, 62f, 28f);
            Rect reverseRect = new Rect(forwardRect.xMax + 4f, toolbar.y + 7f, 62f, 28f);
            if (GUI.Button(
                    forwardRect,
                    "正向依赖",
                    _showReverseReferences ? _segmentStyle : _segmentActiveStyle))
            {
                SetReverseReferences(false);
            }
            if (GUI.Button(
                    reverseRect,
                    "反向引用",
                    _showReverseReferences ? _segmentActiveStyle : _segmentStyle))
            {
                SetReverseReferences(true);
            }

            Rect directRect = new Rect(reverseRect.xMax + 10f, toolbar.y + 7f, 44f, 28f);
            Rect recursiveRect = new Rect(directRect.xMax + 4f, toolbar.y + 7f, 44f, 28f);
            if (GUI.Button(
                    directRect,
                    "直接",
                    _showRecursiveDependencies ? _segmentStyle : _segmentActiveStyle))
            {
                _showRecursiveDependencies = false;
            }
            if (GUI.Button(
                    recursiveRect,
                    "递归",
                    _showRecursiveDependencies ? _segmentActiveStyle : _segmentStyle))
            {
                _showRecursiveDependencies = true;
            }

            Rect externalCheck = new Rect(toolbar.xMax - 110f, toolbar.y + 13f, 16f, 16f);
            Rect externalLabel = new Rect(toolbar.xMax - 90f, toolbar.y + 8f, 84f, 28f);
            if (DrawCheckbox(externalCheck, _showOnlyExternalDependencies, true)
                || GUI.Button(externalLabel, GUIContent.none, GUIStyle.none))
            {
                _showOnlyExternalDependencies = !_showOnlyExternalDependencies;
            }
            GUI.Label(new Rect(toolbar.xMax - 88f, toolbar.y + 12f, 80f, 18f), "仅输入范围外", _subtitleStyle);
        }

        private void DrawDependencyRows()
        {
            IReadOnlyList<ReferenceDisplayItem> references = GetActiveReferenceItems();
            if (references.Count == 0)
            {
                EditorGUILayout.Space(22f);
                Rect empty = GUILayoutUtility.GetRect(0f, 54f, GUILayout.ExpandWidth(true));
                GUI.Label(
                    empty,
                    _showReverseReferences ? "没有找到引用当前资产的位置" : "没有符合当前条件的依赖资产",
                    _centerMutedStyle);
                return;
            }

            foreach (ReferenceDisplayItem reference in references)
            {
                DrawDependencyRow(reference);
            }
        }

        private void DrawDependencyRow(ReferenceDisplayItem reference)
        {
            string dependencyPath = reference.AssetPath;
            Object asset = AssetDatabase.LoadMainAssetAtPath(dependencyPath);
            bool hasImageThumbnail = IsImageAsset(asset);
            float rowHeight = hasImageThumbnail ? ImageDependencyRowHeight : DependencyRowHeight;
            Rect row = GUILayoutUtility.GetRect(0f, rowHeight, GUILayout.ExpandWidth(true));
            row = new Rect(row.x + 6f, row.y, row.width - 12f, row.height);
            DrawRowBackground(row, false);

            bool eligible = !_showReverseReferences
                && _includeDependenciesOnDelete
                && _eligibleDependencyAssets.Contains(dependencyPath);
            bool selected = _selectedDependencyAssets.Contains(dependencyPath);
            Rect checkRect = new Rect(row.x + 10f, row.y + (row.height - 16f) * 0.5f, 16f, 16f);
            if (DrawCheckbox(checkRect, selected, eligible))
            {
                SetDependencySelected(dependencyPath, !selected);
            }

            float contentX;
            if (hasImageThumbnail)
            {
                Rect previewRect = new Rect(row.x + 36f, row.y + 10f, 48f, 48f);
                DrawImagePreview(previewRect, dependencyPath, asset);
                contentX = previewRect.xMax + 10f;
            }
            else
            {
                Rect iconRect = new Rect(row.x + 36f, row.y + (row.height - 24f) * 0.5f, 24f, 24f);
                DrawMiniAssetIcon(iconRect, dependencyPath, asset);
                contentX = iconRect.xMax + 9f;
            }

            float relationWidth = 62f;
            float locationWidth = 64f;
            float locateWidth = 32f;
            Rect locateRect = new Rect(
                row.xMax - locateWidth - 8f,
                row.y + (row.height - 32f) * 0.5f,
                locateWidth,
                32f);
            Rect locationRect = new Rect(
                locateRect.x - locationWidth - 8f,
                row.y + (row.height - 22f) * 0.5f,
                locationWidth,
                22f);
            Rect relationRect = new Rect(
                locationRect.x - relationWidth - 6f,
                row.y + (row.height - 22f) * 0.5f,
                relationWidth,
                22f);
            Rect nameRect = new Rect(
                contentX,
                row.y + (hasImageThumbnail ? 10f : 5f),
                Mathf.Max(70f, relationRect.x - contentX - 8f),
                row.height - (hasImageThumbnail ? 20f : 10f));
            DrawDependencyName(nameRect, dependencyPath);

            string location = GetDependencyLocation(dependencyPath);
            GetLocationBadgeColors(location, out Color badgeText, out Color badgeBackground);
            GetRelationBadgeColors(reference.RelationKind, out Color relationText, out Color relationBackground);
            DrawPill(relationRect, GetRelationLabel(reference.RelationKind), relationText, relationBackground);
            DrawPill(locationRect, location, badgeText, badgeBackground);
            DrawLocateButton(locateRect, dependencyPath);
        }

        private void DrawImagePreview(Rect rect, string assetPath, Object asset)
        {
            Texture preview = AssetPreview.GetAssetPreview(asset);
            if (preview == null)
            {
                preview = AssetPreview.GetMiniThumbnail(asset);
                if (AssetPreview.IsLoadingAssetPreview(asset.GetInstanceID()))
                {
                    _waitingForPreviews = true;
                }
            }

            EditorGUI.DrawRect(new Rect(rect.x - 1f, rect.y - 1f, rect.width + 2f, rect.height + 2f), BorderColor);
            EditorGUI.DrawRect(rect, HeaderColor);
            if (preview != null)
            {
                GUI.DrawTexture(rect, preview, ScaleMode.ScaleToFit, true);
            }

            if (GUI.Button(rect, new GUIContent(string.Empty, "在 Project 窗口中定位"), GUIStyle.none))
            {
                PingAsset(assetPath);
            }
        }

        private static void DrawMiniAssetIcon(Rect rect, string assetPath, Object asset)
        {
            Texture icon = asset == null ? null : AssetPreview.GetMiniThumbnail(asset);
            if (icon == null)
            {
                icon = AssetDatabase.GetCachedIcon(assetPath);
            }
            if (icon != null)
            {
                GUI.DrawTexture(rect, icon, ScaleMode.ScaleToFit, true);
            }
        }

        private void DrawDependencyName(Rect rect, string assetPath)
        {
            string fileName = Path.GetFileName(assetPath);
            Rect top = new Rect(rect.x, rect.y + 2f, rect.width, 18f);
            Rect bottom = new Rect(rect.x, rect.y + 22f, rect.width, 17f);
            if (GUI.Button(top, new GUIContent(fileName, "在 Project 窗口中定位"), _rowButtonStyle))
            {
                PingAsset(assetPath);
            }
            GUI.Label(bottom, assetPath + " · " + GetAssetTypeLabel(assetPath), _pathStyle);
        }

        private void DrawDeleteFooter()
        {
            Rect footerArea = GUILayoutUtility.GetRect(0f, 84f, GUILayout.ExpandWidth(true));
            Rect footer = new Rect(footerArea.x + 14f, footerArea.y + 10f, footerArea.width - 28f, 64f);
            EditorGUI.DrawRect(footer, PanelColor);
            DrawBorder(footer, BorderColor);

            GUI.Label(
                new Rect(footer.x + 16f, footer.y + 10f, 250f, 21f),
                "已选择 " + _selectedSourceAssets.Count + " 个导入资产",
                _sectionTitleStyle);
            GUI.Label(
                new Rect(footer.x + 16f, footer.y + 33f, 270f, 17f),
                _showReverseReferences
                    ? "反向引用仅用于查看和定位"
                    : _includeDependenciesOnDelete
                        ? "另选 " + _selectedDependencyAssets.Count + " 个依赖资产"
                        : "依赖资产不会被删除",
                _subtitleStyle);

            float controlsX = Mathf.Max(footer.x + 300f, footer.xMax - 460f);
            Rect includeCheck = new Rect(controlsX, footer.y + 24f, 16f, 16f);
            Rect includeLabel = new Rect(includeCheck.xMax + 3f, footer.y + 17f, 112f, 30f);
            using (new EditorGUI.DisabledScope(_showReverseReferences))
            {
                if (DrawCheckbox(includeCheck, _includeDependenciesOnDelete, true)
                    || GUI.Button(includeLabel, GUIContent.none, GUIStyle.none))
                {
                    SetIncludeDependencies(!_includeDependenciesOnDelete);
                }
                GUI.Label(
                    new Rect(includeCheck.xMax + 7f, footer.y + 21f, 104f, 22f),
                    "同时删除依赖项",
                    _subtitleStyle);
            }

            Rect protectCheck = new Rect(controlsX + 132f, footer.y + 24f, 16f, 16f);
            Rect protectLabel = new Rect(protectCheck.xMax + 3f, footer.y + 17f, 104f, 30f);
            using (new EditorGUI.DisabledScope(_showReverseReferences))
            {
                if (DrawCheckbox(protectCheck, _protectSharedDependencies, true)
                    || GUI.Button(protectLabel, GUIContent.none, GUIStyle.none))
                {
                    _protectSharedDependencies = !_protectSharedDependencies;
                    RefreshDependencySelection();
                }
                GUI.Label(
                    new Rect(protectCheck.xMax + 7f, footer.y + 21f, 96f, 22f),
                    "保护共享依赖",
                    _subtitleStyle);
            }

            using (new EditorGUI.DisabledScope(_selectedSourceAssets.Count == 0))
            {
                GUIContent delete = EditorGUIUtility.IconContent("TreeEditor.Trash");
                delete.text = " 预览删除";
                if (GUI.Button(new Rect(footer.xMax - 128f, footer.y + 13f, 112f, 38f), delete, _dangerButtonStyle))
                {
                    DeleteSelectedAssets();
                }
            }
        }

        private IReadOnlyList<string> GetActiveDependencies()
        {
            AssetDependencyRecord[] records = GetActiveRecords();
            IEnumerable<string> dependencies = _showRecursiveDependencies
                ? records.SelectMany(record => record.RecursiveDependencies)
                : records.SelectMany(record => record.DirectDependencies);
            if (_showOnlyExternalDependencies)
            {
                var scannedAssets = new HashSet<string>(
                    _scanResult.Records.Select(record => record.AssetPath),
                    StringComparer.OrdinalIgnoreCase);
                dependencies = dependencies.Where(path => !scannedAssets.Contains(path));
            }

            return dependencies
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderBy(path => path, StringComparer.OrdinalIgnoreCase)
                .ToArray();
        }

        private IReadOnlyList<ReferenceDisplayItem> GetActiveReferenceItems()
        {
            return _showReverseReferences
                ? GetActiveReverseReferences()
                : GetActiveForwardReferences();
        }

        private IReadOnlyList<ReferenceDisplayItem> GetActiveForwardReferences()
        {
            AssetDependencyRecord[] records = GetActiveRecords();
            var direct = new HashSet<string>(
                records.SelectMany(record => record.DirectDependencies),
                StringComparer.OrdinalIgnoreCase);
            IEnumerable<string> paths = _showRecursiveDependencies
                ? records.SelectMany(record => record.RecursiveDependencies)
                : direct;
            return FilterReferencePaths(paths)
                .Select(path => new ReferenceDisplayItem(
                    path,
                    direct.Contains(path) ? ReferenceRelationKind.Direct : ReferenceRelationKind.Indirect))
                .ToArray();
        }

        private IReadOnlyList<ReferenceDisplayItem> GetActiveReverseReferences()
        {
            if (_projectSnapshot == null)
            {
                return Array.Empty<ReferenceDisplayItem>();
            }

            string[] targetPaths = GetActiveRecords()
                .Select(record => record.AssetPath)
                .ToArray();
            if (targetPaths.Length == 0)
            {
                return Array.Empty<ReferenceDisplayItem>();
            }

            var directAssetReferences = new HashSet<string>(
                _projectSnapshot.GetReferences(targetPaths, false),
                StringComparer.OrdinalIgnoreCase);
            IReadOnlyList<string> assetReferences = _projectSnapshot.GetReferences(
                targetPaths,
                _showRecursiveDependencies);
            var items = new Dictionary<string, ReferenceRelationKind>(StringComparer.OrdinalIgnoreCase);
            foreach (string assetPath in assetReferences)
            {
                items[assetPath] = directAssetReferences.Contains(assetPath)
                    ? ReferenceRelationKind.Direct
                    : ReferenceRelationKind.Indirect;
            }

            string[] codeTargets = targetPaths.Where(IsCSharpSource).ToArray();
            if (_codeReferenceSnapshot != null && codeTargets.Length > 0)
            {
                foreach (string codeReference in _codeReferenceSnapshot.GetReferences(
                             codeTargets,
                             _showRecursiveDependencies))
                {
                    if (!items.TryGetValue(codeReference, out ReferenceRelationKind existing)
                        || existing == ReferenceRelationKind.Indirect)
                    {
                        items[codeReference] = ReferenceRelationKind.Code;
                    }
                }
            }

            return FilterReferencePaths(items.Keys)
                .Select(path => new ReferenceDisplayItem(path, items[path]))
                .ToArray();
        }

        private IEnumerable<string> FilterReferencePaths(IEnumerable<string> paths)
        {
            IEnumerable<string> filtered = paths;
            if (_showOnlyExternalDependencies)
            {
                var scannedAssets = new HashSet<string>(
                    _scanResult.Records.Select(record => record.AssetPath),
                    StringComparer.OrdinalIgnoreCase);
                filtered = filtered.Where(path => !scannedAssets.Contains(path));
            }

            return filtered
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderBy(path => path, StringComparer.OrdinalIgnoreCase);
        }

        private AssetDependencyRecord[] GetActiveRecords()
        {
            if (string.IsNullOrEmpty(_activePath))
            {
                return Array.Empty<AssetDependencyRecord>();
            }

            if (AssetDatabase.IsValidFolder(_activePath))
            {
                return _scanResult.Records
                    .Where(record => AssetPathUtility.IsInsideFolder(record.AssetPath, _activePath))
                    .ToArray();
            }

            AssetDependencyRecord record = FindRecord(_activePath);
            return record == null ? Array.Empty<AssetDependencyRecord>() : new[] { record };
        }

        private IReadOnlyList<string> GetDependencies(IEnumerable<AssetDependencyRecord> records)
        {
            return records
                .SelectMany(record => _showRecursiveDependencies
                    ? record.RecursiveDependencies
                    : record.DirectDependencies)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToArray();
        }

        private string GetDependencyLocation(string assetPath)
        {
            if (AssetPathUtility.IsPackageAsset(assetPath))
            {
                return "包资源";
            }
            if (!AssetPathUtility.IsProjectAsset(assetPath))
            {
                return "内置";
            }
            if (_protectedCodeAssets.Contains(assetPath))
            {
                return "代码保护";
            }
            if (_sharedDependencyAssets.Contains(assetPath))
            {
                return "共享依赖";
            }
            if (_scanResult.Records.Any(record => record.AssetPath.Equals(assetPath, StringComparison.OrdinalIgnoreCase)))
            {
                return "导入资产";
            }
            return "文件夹外";
        }

        private void SetIncludeDependencies(bool include)
        {
            _includeDependenciesOnDelete = include;
            _selectedDependencyAssets.Clear();
            _excludedDependencyAssets.Clear();
            _eligibleDependencyAssets.Clear();
            _sharedDependencyAssets.Clear();
            _protectedCodeAssets.Clear();
            if (!include)
            {
                return;
            }

            try
            {
                if (_projectSnapshot == null)
                {
                    _projectSnapshot = ProjectDependencySnapshot.Capture(DisplayProgress);
                }
                RefreshDependencySelection();
            }
            catch (OperationCanceledException)
            {
                _includeDependenciesOnDelete = false;
                ShowNotification(new GUIContent("引用索引已取消"));
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }
        }

        private void RefreshDependencySelection()
        {
            if (!_includeDependenciesOnDelete || _scanResult == null || _projectSnapshot == null)
            {
                return;
            }

            DeletionPlan plan = DeletionPlanner.Build(
                _scanResult,
                _selectedSourceAssets,
                null,
                true,
                _protectSharedDependencies,
                true,
                _projectSnapshot);
            ReplaceSet(_eligibleDependencyAssets, plan.DependencyAssets);
            ReplaceSet(_sharedDependencyAssets, plan.SharedDependencies);
            ReplaceSet(_protectedCodeAssets, plan.ProtectedCodeDependencies);
            _selectedDependencyAssets.RemoveWhere(path => !_eligibleDependencyAssets.Contains(path));
            foreach (string dependency in _eligibleDependencyAssets)
            {
                if (!_excludedDependencyAssets.Contains(dependency))
                {
                    _selectedDependencyAssets.Add(dependency);
                }
            }
        }

        private void SetDependencySelected(string assetPath, bool selected)
        {
            if (selected)
            {
                _selectedDependencyAssets.Add(assetPath);
                _excludedDependencyAssets.Remove(assetPath);
            }
            else
            {
                _selectedDependencyAssets.Remove(assetPath);
                _excludedDependencyAssets.Add(assetPath);
            }
        }

        private void SourceSelectionChanged()
        {
            RefreshDependencySelection();
            Repaint();
        }

        private void SelectAllSources()
        {
            foreach (AssetDependencyRecord record in _scanResult.Records)
            {
                if (AssetPathUtility.IsProjectAsset(record.AssetPath))
                {
                    _selectedSourceAssets.Add(record.AssetPath);
                }
            }
            SourceSelectionChanged();
        }

        private void SetSourceSelected(string assetPath, bool selected)
        {
            if (selected) _selectedSourceAssets.Add(assetPath);
            else _selectedSourceAssets.Remove(assetPath);
        }

        private void SetActivePath(string assetPath)
        {
            _activePath = assetPath;
            _sourceListHasKeyboardFocus = true;
            _dependencyScroll = Vector2.zero;
            if (_showReverseReferences)
            {
                EnsureReverseIndexesForActive();
            }
            Focus();
            Repaint();
        }

        private void SetReverseReferences(bool reverse)
        {
            if (_showReverseReferences == reverse)
            {
                return;
            }

            if (reverse && !EnsureReverseIndexesForActive())
            {
                return;
            }

            if (reverse)
            {
                SetIncludeDependencies(false);
            }
            _showReverseReferences = reverse;
            _dependencyScroll = Vector2.zero;
            Repaint();
        }

        private bool EnsureReverseIndexesForActive()
        {
            try
            {
                if (_projectSnapshot == null)
                {
                    _projectSnapshot = ProjectDependencySnapshot.Capture(DisplayProgress);
                }

                bool includesCode = GetActiveRecords().Any(record => IsCSharpSource(record.AssetPath));
                if (includesCode && _codeReferenceSnapshot == null)
                {
                    string[] codeTargets = _scanResult.Records
                        .Select(record => record.AssetPath)
                        .Where(IsCSharpSource)
                        .ToArray();
                    _codeReferenceSnapshot = CSharpReferenceSnapshot.Capture(codeTargets, DisplayProgress);
                }
                return true;
            }
            catch (OperationCanceledException)
            {
                ShowNotification(new GUIContent("反向引用索引已取消"));
                return false;
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }
        }

        private static bool IsCSharpSource(string assetPath)
        {
            return assetPath.EndsWith(".cs", StringComparison.OrdinalIgnoreCase);
        }

        private void DeleteSelectedAssets()
        {
            DeletionPlan plan;
            try
            {
                plan = DeletionPlanner.Build(
                    _scanResult,
                    _selectedSourceAssets,
                    _selectedDependencyAssets,
                    _includeDependenciesOnDelete,
                    _protectSharedDependencies,
                    true,
                    _projectSnapshot,
                    DisplayProgress);
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }

            if (plan.Cancelled)
            {
                ShowNotification(new GUIContent("删除分析已取消"));
                return;
            }

            string preview = BuildDeletionPreview(plan);
            if (!EditorUtility.DisplayDialog("确认删除", preview, "移入回收站", "返回调整"))
            {
                return;
            }

            AssetDeletionResult result = AssetDeletionService.MoveToTrash(plan);
            if (result.Failures.Count == 0)
            {
                EditorUtility.DisplayDialog(
                    "删除完成",
                    "已删除 " + plan.SourceAssets.Count + " 个导入资产和 "
                    + plan.DependencyAssets.Count + " 个依赖资产。",
                    "确定");
            }
            else
            {
                var message = new StringBuilder();
                message.AppendLine("以下资源删除失败：");
                message.AppendLine(string.Join("\n", result.Failures));
                if (result.SkippedDependencyAssets.Count > 0)
                {
                    message.AppendLine();
                    message.AppendLine("为避免断链，已停止删除所有引用项。");
                }
                EditorUtility.DisplayDialog("部分资源删除失败", message.ToString(), "确定");
            }

            RemoveMissingInputs();
            Scan(false);
            GUIUtility.ExitGUI();
        }

        private static string BuildDeletionPreview(DeletionPlan plan)
        {
            var builder = new StringBuilder();
            builder.AppendLine("导入资产：" + plan.SourceAssets.Count + " 个");
            builder.AppendLine("依赖资产：" + plan.DependencyAssets.Count + " 个");
            if (plan.SharedDependencies.Count > 0)
            {
                builder.AppendLine("已保护共享依赖：" + plan.SharedDependencies.Count + " 个");
            }
            if (plan.ProtectedCodeDependencies.Count > 0)
            {
                builder.AppendLine("已保护脚本和程序集：" + plan.ProtectedCodeDependencies.Count + " 个");
            }
            if (plan.NonProjectDependencies.Count > 0)
            {
                builder.AppendLine("已保护包资源或内置资源：" + plan.NonProjectDependencies.Count + " 个");
            }
            builder.AppendLine();
            AppendPreviewPaths(builder, plan.SourceAssets.Concat(plan.DependencyAssets), 14);
            builder.AppendLine();
            builder.Append("Unity 的撤销功能无法恢复此操作；系统支持时，文件会被移入回收站。");
            return builder.ToString();
        }

        private static void AppendPreviewPaths(StringBuilder builder, IEnumerable<string> paths, int limit)
        {
            string[] pathArray = paths.ToArray();
            foreach (string path in pathArray.Take(limit))
            {
                builder.AppendLine("- " + path);
            }
            if (pathArray.Length > limit)
            {
                builder.AppendLine("……另有 " + (pathArray.Length - limit) + " 项");
            }
        }

        private void HandleDragAndDrop(Rect dropRect)
        {
            Event current = Event.current;
            if (!dropRect.Contains(current.mousePosition)
                || (current.type != EventType.DragUpdated && current.type != EventType.DragPerform))
            {
                return;
            }

            List<string> paths = ExtractDraggedAssetPaths();
            DragAndDrop.visualMode = paths.Count > 0 ? DragAndDropVisualMode.Copy : DragAndDropVisualMode.Rejected;
            if (current.type == EventType.DragPerform && paths.Count > 0)
            {
                DragAndDrop.AcceptDrag();
                AddInputPaths(paths);
            }
            current.Use();
        }

        private static List<string> ExtractDraggedAssetPaths()
        {
            var paths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (Object draggedObject in DragAndDrop.objectReferences)
            {
                string path = AssetPathUtility.Normalize(AssetDatabase.GetAssetPath(draggedObject));
                if (IsAcceptedInputPath(path))
                {
                    paths.Add(path);
                }
            }

            foreach (string draggedPath in DragAndDrop.paths)
            {
                string path = AssetPathUtility.Normalize(draggedPath);
                if (IsAcceptedInputPath(path))
                {
                    paths.Add(path);
                }
                else if (AssetPathUtility.TryConvertAbsoluteFolderToAssetPath(path, out string converted)
                    && IsAcceptedInputPath(converted))
                {
                    paths.Add(converted);
                }
            }
            return paths.ToList();
        }

        private static bool IsAcceptedInputPath(string path)
        {
            bool validRoot = AssetPathUtility.IsProjectAsset(path) || AssetPathUtility.IsPackageAsset(path);
            return validRoot && (AssetDatabase.IsValidFolder(path) || AssetDatabase.LoadMainAssetAtPath(path) != null);
        }

        private void AddFolderFromDialog()
        {
            string selected = EditorUtility.OpenFolderPanel("选择 Assets 下的文件夹", Application.dataPath, string.Empty);
            if (string.IsNullOrEmpty(selected))
            {
                return;
            }
            if (!AssetPathUtility.TryConvertAbsoluteFolderToAssetPath(selected, out string assetPath)
                || !AssetDatabase.IsValidFolder(assetPath))
            {
                ShowNotification(new GUIContent("请选择当前项目 Assets 下的文件夹。"));
                return;
            }
            AddInputPaths(new[] { assetPath });
        }

        private void AddInputPaths(IEnumerable<string> paths)
        {
            _inputPaths.AddRange(paths);
            IReadOnlyList<string> normalized = AssetPathUtility.RemoveNestedFolders(_inputPaths);
            _inputPaths.Clear();
            _inputPaths.AddRange(normalized);
            foreach (string path in _inputPaths.Where(AssetDatabase.IsValidFolder))
            {
                _expandedFolders.Add(path);
            }
            Scan(false);
        }

        private void Scan(bool preserveSelection)
        {
            if (_inputPaths.Count == 0)
            {
                ClearResults();
                return;
            }

            HashSet<string> previousSelection = preserveSelection
                ? new HashSet<string>(_selectedSourceAssets, StringComparer.OrdinalIgnoreCase)
                : new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            try
            {
                _scanResult = DependencyScanService.Scan(_inputPaths, DisplayProgress);
                _inputPaths.Clear();
                _inputPaths.AddRange(_scanResult.InputPaths);
                _selectedSourceAssets.Clear();
                foreach (string path in previousSelection)
                {
                    if (_scanResult.Records.Any(record => record.AssetPath.Equals(path, StringComparison.OrdinalIgnoreCase)))
                    {
                        _selectedSourceAssets.Add(path);
                    }
                }
                _selectedDependencyAssets.Clear();
                _excludedDependencyAssets.Clear();
                _eligibleDependencyAssets.Clear();
                _sharedDependencyAssets.Clear();
                _protectedCodeAssets.Clear();
                _projectSnapshot = null;
                _codeReferenceSnapshot = null;
                _includeDependenciesOnDelete = false;
                if (string.IsNullOrEmpty(_activePath)
                    || (!_scanResult.InputPaths.Contains(_activePath, StringComparer.OrdinalIgnoreCase)
                        && FindRecord(_activePath) == null))
                {
                    _activePath = _scanResult.InputPaths.FirstOrDefault() ?? string.Empty;
                }
                foreach (string error in _scanResult.Errors)
                {
                    Debug.LogWarning("[依赖检索器] " + error);
                }
            }
            catch (OperationCanceledException)
            {
                ShowNotification(new GUIContent("扫描已取消"));
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }
            if (_showReverseReferences && _scanResult != null && !EnsureReverseIndexesForActive())
            {
                _showReverseReferences = false;
            }
            Repaint();
        }

        private void RemoveMissingInputs()
        {
            _inputPaths.RemoveAll(path => !AssetDatabase.IsValidFolder(path) && AssetDatabase.LoadMainAssetAtPath(path) == null);
        }

        private void Clear()
        {
            _inputPaths.Clear();
            _expandedFolders.Clear();
            ClearResults();
        }

        private void ClearResults()
        {
            _scanResult = null;
            _projectSnapshot = null;
            _codeReferenceSnapshot = null;
            _selectedSourceAssets.Clear();
            _selectedDependencyAssets.Clear();
            _excludedDependencyAssets.Clear();
            _eligibleDependencyAssets.Clear();
            _sharedDependencyAssets.Clear();
            _protectedCodeAssets.Clear();
            _activePath = string.Empty;
            _search = string.Empty;
            _includeDependenciesOnDelete = false;
            _showReverseReferences = false;
            Repaint();
        }

        private AssetDependencyRecord FindRecord(string assetPath)
        {
            return _scanResult?.Records.FirstOrDefault(record =>
                record.AssetPath.Equals(assetPath, StringComparison.OrdinalIgnoreCase));
        }

        private bool RecordMatchesSearch(AssetDependencyRecord record)
        {
            return MatchesSearch(record.AssetPath);
        }

        private bool MatchesSearch(string path)
        {
            return string.IsNullOrWhiteSpace(_search)
                || path.IndexOf(_search, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static void ReplaceSet(HashSet<string> target, IEnumerable<string> values)
        {
            target.Clear();
            foreach (string value in values)
            {
                target.Add(value);
            }
        }

        private static bool IsImageAsset(Object asset)
        {
            return asset is Texture || asset is Sprite;
        }

        private static string GetAssetTypeLabel(string assetPath)
        {
            string extension = Path.GetExtension(assetPath);
            if (extension.Equals(".prefab", StringComparison.OrdinalIgnoreCase)) return "预制体";
            if (extension.Equals(".mat", StringComparison.OrdinalIgnoreCase)) return "材质";
            if (extension.Equals(".unity", StringComparison.OrdinalIgnoreCase)) return "场景";
            if (extension.Equals(".shader", StringComparison.OrdinalIgnoreCase)) return "Shader";
            if (AssetPathUtility.IsCodeAsset(assetPath)) return "代码";
            Type type = AssetDatabase.GetMainAssetTypeAtPath(assetPath);
            if (type == typeof(Texture2D) || type == typeof(Sprite)) return "图片";
            if (type == typeof(AudioClip)) return "音频";
            if (type == typeof(AnimationClip)) return "动画";
            return type == null ? "资源" : type.Name;
        }

        private static void DrawRowBackground(Rect row, bool active)
        {
            if (active)
            {
                EditorGUI.DrawRect(row, SelectedColor);
                EditorGUI.DrawRect(new Rect(row.x, row.y, 3f, row.height), AccentColor);
            }
            else if (row.Contains(Event.current.mousePosition))
            {
                EditorGUI.DrawRect(row, HoverColor);
            }
            EditorGUI.DrawRect(new Rect(row.x, row.yMax - 1f, row.width, 1f), BorderColor);
        }

        private void DrawLocateButton(Rect rect, string assetPath)
        {
            GUIContent locate = EditorGUIUtility.IconContent("ViewToolZoom");
            locate.tooltip = "在 Project 窗口中定位";
            if (GUI.Button(rect, locate, _iconButtonStyle))
            {
                PingAsset(assetPath);
            }
        }

        private bool DrawCheckbox(Rect rect, bool selected, bool enabled, bool mixed = false)
        {
            bool interactive = enabled && GUI.enabled;
            Color boxColor = interactive ? RaisedColor : new Color(RaisedColor.r, RaisedColor.g, RaisedColor.b, 0.52f);
            Color outline = interactive ? BorderColor : new Color(BorderColor.r, BorderColor.g, BorderColor.b, 0.45f);
            EditorGUI.DrawRect(rect, outline);
            EditorGUI.DrawRect(new Rect(rect.x + 1f, rect.y + 1f, rect.width - 2f, rect.height - 2f), boxColor);

            if (selected || mixed)
            {
                Rect fill = new Rect(rect.x + 2f, rect.y + 2f, rect.width - 4f, rect.height - 4f);
                EditorGUI.DrawRect(fill, interactive ? AccentColor : MutedTextColor);
                if (mixed)
                {
                    EditorGUI.DrawRect(new Rect(rect.x + 4f, rect.center.y - 1f, rect.width - 8f, 2f), TextColor);
                }
                else
                {
                    GUI.Label(fill, "✓", _checkStyle);
                }
            }

            return interactive && GUI.Button(rect, GUIContent.none, GUIStyle.none);
        }

        private void DrawPill(Rect rect, string text, Color textColor, Color backgroundColor)
        {
            EditorGUI.DrawRect(rect, backgroundColor);
            Color previous = _badgeStyle.normal.textColor;
            _badgeStyle.normal.textColor = textColor;
            GUI.Label(rect, text, _badgeStyle);
            _badgeStyle.normal.textColor = previous;
        }

        private static void DrawBorder(Rect rect, Color color)
        {
            EditorGUI.DrawRect(new Rect(rect.x, rect.y, rect.width, 1f), color);
            EditorGUI.DrawRect(new Rect(rect.x, rect.yMax - 1f, rect.width, 1f), color);
            EditorGUI.DrawRect(new Rect(rect.x, rect.y, 1f, rect.height), color);
            EditorGUI.DrawRect(new Rect(rect.xMax - 1f, rect.y, 1f, rect.height), color);
        }

        private static void GetLocationBadgeColors(string location, out Color text, out Color background)
        {
            switch (location)
            {
                case "共享依赖":
                    text = new Color(0.953f, 0.725f, 0.278f);
                    background = new Color(0.255f, 0.192f, 0.086f);
                    break;
                case "代码保护":
                    text = new Color(0.925f, 0.518f, 0.631f);
                    background = new Color(0.267f, 0.122f, 0.169f);
                    break;
                case "导入资产":
                    text = new Color(0.420f, 0.714f, 0.941f);
                    background = new Color(0.102f, 0.200f, 0.298f);
                    break;
                case "文件夹外":
                    text = AccentColor;
                    background = SelectedColor;
                    break;
                default:
                    text = MutedTextColor;
                    background = RaisedColor;
                    break;
            }
        }

        private string GetRelationLabel(ReferenceRelationKind relationKind)
        {
            switch (relationKind)
            {
                case ReferenceRelationKind.Code:
                    return "代码引用";
                case ReferenceRelationKind.Indirect:
                    return _showReverseReferences ? "间接引用" : "间接依赖";
                default:
                    return _showReverseReferences ? "直接引用" : "直接依赖";
            }
        }

        private static void GetRelationBadgeColors(
            ReferenceRelationKind relationKind,
            out Color text,
            out Color background)
        {
            switch (relationKind)
            {
                case ReferenceRelationKind.Code:
                    text = new Color(0.925f, 0.518f, 0.631f);
                    background = new Color(0.267f, 0.122f, 0.169f);
                    break;
                case ReferenceRelationKind.Indirect:
                    text = new Color(0.953f, 0.725f, 0.278f);
                    background = new Color(0.255f, 0.192f, 0.086f);
                    break;
                default:
                    text = AccentColor;
                    background = SelectedColor;
                    break;
            }
        }

        private static GUIStyle CreateButtonStyle(
            Texture2D normalBackground,
            Texture2D hoverBackground,
            int horizontalPadding,
            TextAnchor alignment)
        {
            var style = new GUIStyle
            {
                alignment = alignment,
                clipping = TextClipping.Clip,
                padding = new RectOffset(horizontalPadding, horizontalPadding, 3, 3),
                fontSize = 10
            };
            style.normal.background = normalBackground;
            style.normal.textColor = TextColor;
            style.hover.background = hoverBackground;
            style.hover.textColor = TextColor;
            style.active.background = hoverBackground;
            style.active.textColor = TextColor;
            style.focused.background = normalBackground;
            style.focused.textColor = TextColor;
            return style;
        }

        private static Texture2D CreateStyleTexture(Color color)
        {
            var texture = new Texture2D(1, 1)
            {
                hideFlags = HideFlags.HideAndDontSave
            };
            texture.SetPixel(0, 0, color);
            texture.Apply();
            return texture;
        }

        private static void DestroyStyleTexture(ref Texture2D texture)
        {
            if (texture == null)
            {
                return;
            }
            DestroyImmediate(texture);
            texture = null;
        }

        private static void PingAsset(string assetPath)
        {
            Object asset = AssetDatabase.LoadMainAssetAtPath(assetPath);
            if (asset == null)
            {
                return;
            }
            Selection.activeObject = asset;
            EditorGUIUtility.PingObject(asset);
        }

        private static bool DisplayProgress(ScanProgress progress)
        {
            return EditorUtility.DisplayCancelableProgressBar(
                progress.Title,
                progress.Detail,
                Mathf.Clamp01(progress.Progress));
        }
    }
}
