using NUnit.Framework;

namespace Spark.DependencyExplorer.Tests
{
    internal sealed class CSharpIdentifierScannerTests
    {
        [Test]
        public void ExtractIdentifiers_FindsCodeIdentifiers()
        {
            const string source = "public sealed class Caller { private TargetService _service; }";

            var identifiers = CSharpIdentifierScanner.ExtractIdentifiers(source);

            Assert.That(identifiers, Does.Contain("Caller"));
            Assert.That(identifiers, Does.Contain("TargetService"));
        }

        [Test]
        public void ExtractIdentifiers_IgnoresCommentsAndStringLiterals()
        {
            const string source = @"
                // CommentOnlyType
                /* BlockCommentType */
                public string Name => ""StringOnlyType"";
                public string Verbatim => @""VerbatimOnlyType"";
                public RealType Value;";

            var identifiers = CSharpIdentifierScanner.ExtractIdentifiers(source);

            Assert.That(identifiers, Does.Contain("RealType"));
            Assert.That(identifiers, Does.Not.Contain("CommentOnlyType"));
            Assert.That(identifiers, Does.Not.Contain("BlockCommentType"));
            Assert.That(identifiers, Does.Not.Contain("StringOnlyType"));
            Assert.That(identifiers, Does.Not.Contain("VerbatimOnlyType"));
        }

        [Test]
        public void ExtractIdentifiers_IgnoresCharacterLiterals()
        {
            const string source = "char value = 'X'; RealType target;";

            var identifiers = CSharpIdentifierScanner.ExtractIdentifiers(source);

            Assert.That(identifiers, Does.Contain("RealType"));
            Assert.That(identifiers, Does.Not.Contain("X"));
        }
    }
}
