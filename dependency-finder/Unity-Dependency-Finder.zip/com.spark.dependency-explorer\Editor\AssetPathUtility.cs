using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;

namespace Spark.DependencyExplorer
{
    internal static class AssetPathUtility
    {
        private static readonly HashSet<string> CodeExtensions = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            ".asmdef",
            ".asmref",
            ".cs",
            ".dll",
            ".rsp"
        };

        public static string Normalize(string path)
        {
            return string.IsNullOrWhiteSpace(path)
                ? string.Empty
                : path.Replace('\\', '/').TrimEnd('/');
        }

        public static bool IsProjectAsset(string path)
        {
            string normalized = Normalize(path);
            return normalized.Equals("Assets", StringComparison.OrdinalIgnoreCase)
                || normalized.StartsWith("Assets/", StringComparison.OrdinalIgnoreCase);
        }

        public static bool IsPackageAsset(string path)
        {
            string normalized = Normalize(path);
            return normalized.Equals("Packages", StringComparison.OrdinalIgnoreCase)
                || normalized.StartsWith("Packages/", StringComparison.OrdinalIgnoreCase);
        }

        public static bool IsCodeAsset(string path)
        {
            return CodeExtensions.Contains(Path.GetExtension(Normalize(path)));
        }

        public static bool IsInsideAnyFolder(string assetPath, IEnumerable<string> folders)
        {
            string normalizedPath = Normalize(assetPath);
            return folders.Any(folder => IsInsideFolder(normalizedPath, folder));
        }

        public static bool IsInsideFolder(string assetPath, string folder)
        {
            string normalizedPath = Normalize(assetPath);
            string normalizedFolder = Normalize(folder);
            return normalizedPath.Equals(normalizedFolder, StringComparison.OrdinalIgnoreCase)
                || normalizedPath.StartsWith(normalizedFolder + "/", StringComparison.OrdinalIgnoreCase);
        }

        public static IReadOnlyList<string> RemoveNestedFolders(IEnumerable<string> folders)
        {
            var normalizedFolders = folders
                .Select(Normalize)
                .Where(path => !string.IsNullOrEmpty(path))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderBy(path => path.Length)
                .ThenBy(path => path, StringComparer.OrdinalIgnoreCase)
                .ToList();

            var result = new List<string>();
            foreach (string folder in normalizedFolders)
            {
                if (!IsInsideAnyFolder(folder, result))
                {
                    result.Add(folder);
                }
            }

            return result;
        }

        public static bool TryConvertAbsoluteFolderToAssetPath(string absolutePath, out string assetPath)
        {
            assetPath = string.Empty;
            if (string.IsNullOrWhiteSpace(absolutePath))
            {
                return false;
            }

            string normalizedAbsolute = Normalize(Path.GetFullPath(absolutePath));
            string normalizedAssets = Normalize(Path.GetFullPath(Application.dataPath));

            if (normalizedAbsolute.Equals(normalizedAssets, StringComparison.OrdinalIgnoreCase))
            {
                assetPath = "Assets";
                return true;
            }

            if (!normalizedAbsolute.StartsWith(normalizedAssets + "/", StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }

            assetPath = "Assets" + normalizedAbsolute.Substring(normalizedAssets.Length);
            return true;
        }
    }
}
