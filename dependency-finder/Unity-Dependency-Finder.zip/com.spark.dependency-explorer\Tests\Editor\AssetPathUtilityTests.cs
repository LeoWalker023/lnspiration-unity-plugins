using System.Linq;
using NUnit.Framework;

namespace Spark.DependencyExplorer.Tests
{
    internal sealed class AssetPathUtilityTests
    {
        [TestCase("Assets\\Art\\Materials\\", "Assets/Art/Materials")]
        [TestCase("Packages/com.spark.example/", "Packages/com.spark.example")]
        [TestCase("", "")]
        public void Normalize_UsesUnitySeparatorsAndRemovesTrailingSlash(string input, string expected)
        {
            Assert.That(AssetPathUtility.Normalize(input), Is.EqualTo(expected));
        }

        [Test]
        public void IsInsideFolder_DoesNotMatchSiblingWithCommonPrefix()
        {
            Assert.That(AssetPathUtility.IsInsideFolder("Assets/Art/Materials/A.mat", "Assets/Art"), Is.True);
            Assert.That(AssetPathUtility.IsInsideFolder("Assets/Artist/A.mat", "Assets/Art"), Is.False);
        }

        [Test]
        public void RemoveNestedFolders_KeepsOnlyTopLevelSelections()
        {
            var result = AssetPathUtility.RemoveNestedFolders(new[]
            {
                "Assets/Art/Materials",
                "Assets/Art",
                "Assets/Audio",
                "Assets/Art/Textures",
                "Assets/Audio"
            });

            Assert.That(result, Is.EquivalentTo(new[] { "Assets/Art", "Assets/Audio" }));
        }

        [Test]
        public void CodeAsset_ProtectsScriptsAndAssembliesButNotShaders()
        {
            Assert.That(AssetPathUtility.IsCodeAsset("Assets/Game/Foo.cs"), Is.True);
            Assert.That(AssetPathUtility.IsCodeAsset("Assets/Plugins/Foo.dll"), Is.True);
            Assert.That(AssetPathUtility.IsCodeAsset("Assets/Shaders/Foo.shader"), Is.False);
        }
    }
}
