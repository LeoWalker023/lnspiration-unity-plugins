using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;

namespace Spark.DependencyExplorer
{
    internal static class DeletionPlanner
    {
        public static DeletionPlan Build(
            DependencyScanResult scanResult,
            IEnumerable<string> selectedSourceAssets,
            IEnumerable<string> requestedDependencyAssets,
            bool includeDependencies,
            bool protectSharedDependencies,
            bool protectCodeDependencies,
            ProjectDependencySnapshot snapshot = null,
            CancelableProgress progress = null)
        {
            var scannedSourceSet = new HashSet<string>(
                scanResult.Records.Select(record => record.AssetPath),
                StringComparer.OrdinalIgnoreCase);
            string[] sourceAssets = selectedSourceAssets
                .Select(AssetPathUtility.Normalize)
                .Where(AssetPathUtility.IsProjectAsset)
                .Where(scannedSourceSet.Contains)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderBy(path => path, StringComparer.OrdinalIgnoreCase)
                .ToArray();

            if (!includeDependencies || sourceAssets.Length == 0)
            {
                return EmptyDependencyPlan(sourceAssets);
            }

            try
            {
                var selectedSourceSet = new HashSet<string>(sourceAssets, StringComparer.OrdinalIgnoreCase);
                var requestedSet = requestedDependencyAssets == null
                    ? null
                    : new HashSet<string>(requestedDependencyAssets, StringComparer.OrdinalIgnoreCase);
                string[] referencedDependencies = scanResult.Records
                    .Where(record => selectedSourceSet.Contains(record.AssetPath))
                    .SelectMany(record => record.RecursiveDependencies)
                    .Select(AssetPathUtility.Normalize)
                    .Where(path => !string.IsNullOrEmpty(path))
                    .Where(path => !scannedSourceSet.Contains(path))
                    .Distinct(StringComparer.OrdinalIgnoreCase)
                    .ToArray();

                string[] nonProject = referencedDependencies
                    .Where(path => !AssetPathUtility.IsProjectAsset(path))
                    .OrderBy(path => path, StringComparer.OrdinalIgnoreCase)
                    .ToArray();
                IEnumerable<string> projectCandidates = referencedDependencies
                    .Where(AssetPathUtility.IsProjectAsset)
                    .Where(path => !AssetDatabase.IsValidFolder(path));

                if (requestedSet != null)
                {
                    projectCandidates = projectCandidates.Where(requestedSet.Contains);
                }

                string[] candidateArray = projectCandidates
                    .Distinct(StringComparer.OrdinalIgnoreCase)
                    .ToArray();
                string[] protectedCode = protectCodeDependencies
                    ? candidateArray.Where(AssetPathUtility.IsCodeAsset).ToArray()
                    : Array.Empty<string>();
                var codeSet = new HashSet<string>(protectedCode, StringComparer.OrdinalIgnoreCase);
                string[] candidates = candidateArray.Where(path => !codeSet.Contains(path)).ToArray();

                IReadOnlyCollection<string> shared = Array.Empty<string>();
                if (protectSharedDependencies && candidates.Length > 0)
                {
                    ProjectDependencySnapshot activeSnapshot = snapshot ?? ProjectDependencySnapshot.Capture(progress);
                    shared = DependencyGraphAnalyzer.FindSharedDependencies(
                        candidates,
                        sourceAssets,
                        activeSnapshot.AllAssets,
                        activeSnapshot.GetDirectDependencies,
                        progress);
                }

                var sharedSet = new HashSet<string>(shared, StringComparer.OrdinalIgnoreCase);
                string[] dependenciesToDelete = candidates
                    .Where(path => !sharedSet.Contains(path))
                    .OrderBy(path => path, StringComparer.OrdinalIgnoreCase)
                    .ToArray();

                return new DeletionPlan(
                    sourceAssets,
                    dependenciesToDelete,
                    shared.OrderBy(path => path, StringComparer.OrdinalIgnoreCase).ToArray(),
                    protectedCode.OrderBy(path => path, StringComparer.OrdinalIgnoreCase).ToArray(),
                    nonProject,
                    false);
            }
            catch (OperationCanceledException)
            {
                return new DeletionPlan(
                    sourceAssets,
                    Array.Empty<string>(),
                    Array.Empty<string>(),
                    Array.Empty<string>(),
                    Array.Empty<string>(),
                    true);
            }
        }

        private static DeletionPlan EmptyDependencyPlan(IReadOnlyList<string> sourceAssets)
        {
            return new DeletionPlan(
                sourceAssets,
                Array.Empty<string>(),
                Array.Empty<string>(),
                Array.Empty<string>(),
                Array.Empty<string>(),
                false);
        }
    }
}
