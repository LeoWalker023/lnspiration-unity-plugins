using System;
using System.Collections.Generic;

namespace Spark.DependencyExplorer
{
    internal static class SourceNavigationUtility
    {
        public static string FindAdjacent(
            IReadOnlyList<string> visiblePaths,
            string currentPath,
            int direction)
        {
            if (visiblePaths == null || visiblePaths.Count == 0 || direction == 0)
            {
                return string.Empty;
            }

            int currentIndex = -1;
            for (int i = 0; i < visiblePaths.Count; i++)
            {
                if (visiblePaths[i].Equals(currentPath, StringComparison.OrdinalIgnoreCase))
                {
                    currentIndex = i;
                    break;
                }
            }

            if (currentIndex < 0)
            {
                return direction > 0 ? visiblePaths[0] : visiblePaths[visiblePaths.Count - 1];
            }

            int nextIndex = Math.Max(0, Math.Min(visiblePaths.Count - 1, currentIndex + Math.Sign(direction)));
            return visiblePaths[nextIndex];
        }
    }
}
