using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using UnityEditor;
using UnityEngine;

namespace Spark.DependencyExplorer.Tests
{
    internal sealed class DependencyScanServiceTests
    {
        private const string TestRoot = "Assets/__SparkDependencyExplorerTests";
        private const string SourceFolder = TestRoot + "/Source";
        private const string DependencyFolder = TestRoot + "/Dependency";
        private const string ExternalFolder = TestRoot + "/External";

        [SetUp]
        public void SetUp()
        {
            AssetDatabase.DeleteAsset(TestRoot);
            AssetDatabase.CreateFolder("Assets", "__SparkDependencyExplorerTests");
            AssetDatabase.CreateFolder(TestRoot, "Source");
            AssetDatabase.CreateFolder(TestRoot, "Dependency");
            AssetDatabase.CreateFolder(TestRoot, "External");

            var texture = new Texture2D(4, 4);
            AssetDatabase.CreateAsset(texture, DependencyFolder + "/Texture.asset");

            CreateMaterial(SourceFolder + "/Material.mat", texture);
            AssetDatabase.SaveAssets();
        }

        [TearDown]
        public void TearDown()
        {
            AssetDatabase.DeleteAsset(TestRoot);
            AssetDatabase.Refresh();
        }

        [Test]
        public void Scan_FindsDependencyOutsideSelectedFolder()
        {
            DependencyScanResult result = DependencyScanService.Scan(new[] { SourceFolder });

            Assert.That(result.Records, Has.Count.EqualTo(1));
            Assert.That(result.Records[0].AssetPath, Is.EqualTo(SourceFolder + "/Material.mat"));
            Assert.That(result.Records[0].DirectDependencies, Does.Contain(DependencyFolder + "/Texture.asset"));
            Assert.That(result.UniqueDependencies, Does.Contain(DependencyFolder + "/Texture.asset"));
        }

        [Test]
        public void DeletionPlan_IncludesAnExclusivelyUsedExternalDependency()
        {
            DependencyScanResult result = DependencyScanService.Scan(new[] { SourceFolder });
            DeletionPlan plan = DeletionPlanner.Build(
                result,
                new[] { SourceFolder + "/Material.mat" },
                null,
                true,
                true,
                true);

            Assert.That(plan.Cancelled, Is.False);
            Assert.That(plan.DependencyAssets, Does.Contain(DependencyFolder + "/Texture.asset"));
            Assert.That(plan.SharedDependencies, Does.Not.Contain(DependencyFolder + "/Texture.asset"));
        }

        [Test]
        public void DeletionPlan_KeepsADependencyUsedOutsideTheSelectedFolder()
        {
            var texture = AssetDatabase.LoadAssetAtPath<Texture2D>(DependencyFolder + "/Texture.asset");
            CreateMaterial(ExternalFolder + "/ExternalMaterial.mat", texture);
            AssetDatabase.SaveAssets();

            DependencyScanResult result = DependencyScanService.Scan(new[] { SourceFolder });
            DeletionPlan plan = DeletionPlanner.Build(
                result,
                new[] { SourceFolder + "/Material.mat" },
                null,
                true,
                true,
                true);

            Assert.That(plan.DependencyAssets, Does.Not.Contain(DependencyFolder + "/Texture.asset"));
            Assert.That(plan.SharedDependencies, Does.Contain(DependencyFolder + "/Texture.asset"));
        }

        [Test]
        public void Scan_AcceptsAnIndividualAsset()
        {
            string materialPath = SourceFolder + "/Material.mat";

            DependencyScanResult result = DependencyScanService.Scan(new[] { materialPath });

            Assert.That(result.InputPaths, Is.EquivalentTo(new[] { materialPath }));
            Assert.That(result.Records.Select(record => record.AssetPath), Is.EquivalentTo(new[] { materialPath }));
            Assert.That(result.Records[0].DirectDependencies, Does.Contain(DependencyFolder + "/Texture.asset"));
        }

        [Test]
        public void ProjectSnapshot_FindsTheMaterialReferencingATexture()
        {
            ProjectDependencySnapshot snapshot = ProjectDependencySnapshot.Capture();

            IReadOnlyList<string> references = snapshot.GetReferences(
                new[] { DependencyFolder + "/Texture.asset" },
                false);

            Assert.That(references, Does.Contain(SourceFolder + "/Material.mat"));
        }

        [Test]
        public void DeletionPlan_DeletesOnlySelectedSourceAssets()
        {
            var texture = AssetDatabase.LoadAssetAtPath<Texture2D>(DependencyFolder + "/Texture.asset");
            string secondMaterial = SourceFolder + "/SecondMaterial.mat";
            CreateMaterial(secondMaterial, texture);
            AssetDatabase.SaveAssets();
            DependencyScanResult result = DependencyScanService.Scan(new[] { SourceFolder });

            DeletionPlan plan = DeletionPlanner.Build(
                result,
                new[] { SourceFolder + "/Material.mat" },
                null,
                false,
                true,
                true);

            Assert.That(plan.SourceAssets, Is.EquivalentTo(new[] { SourceFolder + "/Material.mat" }));
            Assert.That(plan.SourceAssets, Does.Not.Contain(secondMaterial));
            Assert.That(plan.DependencyAssets, Is.Empty);
        }

        [Test]
        public void DeletionPlan_HonorsIndividualDependencySelection()
        {
            DependencyScanResult result = DependencyScanService.Scan(new[] { SourceFolder });

            DeletionPlan plan = DeletionPlanner.Build(
                result,
                new[] { SourceFolder + "/Material.mat" },
                Array.Empty<string>(),
                true,
                true,
                true);

            Assert.That(plan.DependencyAssets, Is.Empty);
        }

        private static void CreateMaterial(string path, Texture texture)
        {
            Shader shader = Shader.Find("Standard");
            Assert.That(shader, Is.Not.Null, "The built-in Standard shader is required by this integration test.");
            var material = new Material(shader);
            material.SetTexture("_MainTex", texture);
            AssetDatabase.CreateAsset(material, path);
        }
    }
}
