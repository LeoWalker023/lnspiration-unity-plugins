using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace Spark.DependencyExplorer.Tests
{
    internal sealed class ReverseReferenceGraphTests
    {
        [Test]
        public void GetReferences_ReturnsDirectReferrersOnly()
        {
            var graph = CreateGraph();

            IReadOnlyList<string> references = graph.GetReferences(new[] { "Assets/Texture.asset" }, false);

            Assert.That(references, Is.EquivalentTo(new[] { "Assets/Material.mat" }));
        }

        [Test]
        public void GetReferences_TraversesReferrersRecursively()
        {
            var graph = CreateGraph();

            IReadOnlyList<string> references = graph.GetReferences(new[] { "Assets/Texture.asset" }, true);

            Assert.That(references, Is.EquivalentTo(new[]
            {
                "Assets/Material.mat",
                "Assets/Effect.prefab",
                "Assets/Scene.unity"
            }));
        }

        [Test]
        public void GetReferences_ExcludesEveryInputTarget()
        {
            var graph = CreateGraph();

            IReadOnlyList<string> references = graph.GetReferences(
                new[] { "Assets/Texture.asset", "Assets/Material.mat" },
                true);

            Assert.That(references, Does.Not.Contain("Assets/Texture.asset"));
            Assert.That(references, Does.Not.Contain("Assets/Material.mat"));
            Assert.That(references, Does.Contain("Assets/Effect.prefab"));
        }

        private static ReverseReferenceGraph CreateGraph()
        {
            return new ReverseReferenceGraph(new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase)
            {
                { "Assets/Texture.asset", Array.Empty<string>() },
                { "Assets/Material.mat", new[] { "Assets/Texture.asset" } },
                { "Assets/Effect.prefab", new[] { "Assets/Material.mat" } },
                { "Assets/Scene.unity", new[] { "Assets/Effect.prefab" } }
            });
        }
    }
}
