using NUnit.Framework;

namespace Spark.DependencyExplorer.Tests
{
    internal sealed class SourceNavigationUtilityTests
    {
        private static readonly string[] Paths =
        {
            "Assets/Folder",
            "Assets/Folder/First.mat",
            "Assets/Folder/Second.mat"
        };

        [Test]
        public void FindAdjacent_MovesUpAndDownInVisibleOrder()
        {
            Assert.That(
                SourceNavigationUtility.FindAdjacent(Paths, Paths[1], -1),
                Is.EqualTo(Paths[0]));
            Assert.That(
                SourceNavigationUtility.FindAdjacent(Paths, Paths[1], 1),
                Is.EqualTo(Paths[2]));
        }

        [Test]
        public void FindAdjacent_StopsAtListBoundaries()
        {
            Assert.That(
                SourceNavigationUtility.FindAdjacent(Paths, Paths[0], -1),
                Is.EqualTo(Paths[0]));
            Assert.That(
                SourceNavigationUtility.FindAdjacent(Paths, Paths[2], 1),
                Is.EqualTo(Paths[2]));
        }

        [Test]
        public void FindAdjacent_ChoosesBoundaryWhenCurrentPathIsHidden()
        {
            Assert.That(
                SourceNavigationUtility.FindAdjacent(Paths, "Assets/Hidden.mat", 1),
                Is.EqualTo(Paths[0]));
            Assert.That(
                SourceNavigationUtility.FindAdjacent(Paths, "Assets/Hidden.mat", -1),
                Is.EqualTo(Paths[2]));
        }
    }
}
