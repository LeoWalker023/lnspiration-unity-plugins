using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace Spark.DependencyExplorer
{
    internal static class DependencyScanService
    {
        public static DependencyScanResult Scan(
            IEnumerable<string> inputPaths,
            CancelableProgress progress = null)
        {
            IReadOnlyList<string> normalizedInputs = AssetPathUtility.RemoveNestedFolders(inputPaths);
            var errors = new List<string>();
            var assetPaths = FindAssets(normalizedInputs);
            var records = new List<AssetDependencyRecord>(assetPaths.Count);
            var allDependencies = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            for (int i = 0; i < assetPaths.Count; i++)
            {
                string assetPath = assetPaths[i];
                if (progress != null && progress(new ScanProgress(
                        "正在扫描资源依赖",
                        assetPath,
                        assetPaths.Count == 0 ? 1f : (float)i / assetPaths.Count)))
                {
                    throw new OperationCanceledException("依赖扫描已取消。");
                }

                try
                {
                    IReadOnlyList<string> direct = GetDependenciesForAsset(assetPath, false);
                    IReadOnlyList<string> recursive = GetDependenciesForAsset(assetPath, true);

                    records.Add(new AssetDependencyRecord(assetPath, direct, recursive));
                    foreach (string dependency in recursive)
                    {
                        allDependencies.Add(dependency);
                    }
                }
                catch (Exception exception)
                {
                    errors.Add(assetPath + ": " + exception.Message);
                    records.Add(new AssetDependencyRecord(assetPath, Array.Empty<string>(), Array.Empty<string>()));
                }
            }

            progress?.Invoke(new ScanProgress("正在扫描资源依赖", "扫描完成", 1f));

            return new DependencyScanResult(
                normalizedInputs,
                records,
                allDependencies.OrderBy(path => path, StringComparer.OrdinalIgnoreCase).ToArray(),
                errors);
        }

        private static List<string> FindAssets(IReadOnlyList<string> inputPaths)
        {
            var paths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string inputPath in inputPaths)
            {
                if (!AssetDatabase.IsValidFolder(inputPath))
                {
                    if (AssetDatabase.LoadMainAssetAtPath(inputPath) != null)
                    {
                        paths.Add(inputPath);
                    }
                    continue;
                }

                foreach (string guid in AssetDatabase.FindAssets(string.Empty, new[] { inputPath }))
                {
                    string path = AssetPathUtility.Normalize(AssetDatabase.GUIDToAssetPath(guid));
                    if (!string.IsNullOrEmpty(path) && !AssetDatabase.IsValidFolder(path))
                    {
                        paths.Add(path);
                    }
                }
            }

            return paths.OrderBy(path => path, StringComparer.OrdinalIgnoreCase).ToList();
        }

        internal static IReadOnlyList<string> GetDependenciesForAsset(string assetPath, bool recursive)
        {
            var dependencies = new HashSet<string>(
                AssetDatabase.GetDependencies(assetPath, recursive)
                .Select(AssetPathUtility.Normalize)
                .Where(path => !string.IsNullOrEmpty(path))
                .Where(path => !path.Equals(assetPath, StringComparison.OrdinalIgnoreCase)),
                StringComparer.OrdinalIgnoreCase);

            AddMaterialDependencies(assetPath, dependencies);
            return dependencies
                .OrderBy(path => path, StringComparer.OrdinalIgnoreCase)
                .ToArray();
        }

        private static void AddMaterialDependencies(string assetPath, ISet<string> dependencies)
        {
            if (!assetPath.EndsWith(".mat", StringComparison.OrdinalIgnoreCase))
            {
                return;
            }

            Material material = AssetDatabase.LoadAssetAtPath<Material>(assetPath);
            if (material == null)
            {
                return;
            }

            AddObjectPath(material.shader, dependencies);
            foreach (string propertyName in material.GetTexturePropertyNames())
            {
                AddObjectPath(material.GetTexture(propertyName), dependencies);
            }
        }

        private static void AddObjectPath(UnityEngine.Object asset, ISet<string> dependencies)
        {
            if (asset == null)
            {
                return;
            }

            string path = AssetPathUtility.Normalize(AssetDatabase.GetAssetPath(asset));
            if (!string.IsNullOrEmpty(path))
            {
                dependencies.Add(path);
            }
        }
    }
}
