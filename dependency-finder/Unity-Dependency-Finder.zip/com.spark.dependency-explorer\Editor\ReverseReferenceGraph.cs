using System;
using System.Collections.Generic;
using System.Linq;

namespace Spark.DependencyExplorer
{
    internal sealed class ReverseReferenceGraph
    {
        private readonly Dictionary<string, string[]> _directReferences;

        public ReverseReferenceGraph(IReadOnlyDictionary<string, string[]> directDependencies)
        {
            var references = new Dictionary<string, HashSet<string>>(StringComparer.OrdinalIgnoreCase);
            foreach (KeyValuePair<string, string[]> pair in directDependencies)
            {
                foreach (string dependency in pair.Value ?? Array.Empty<string>())
                {
                    if (string.IsNullOrEmpty(dependency)
                        || dependency.Equals(pair.Key, StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }

                    if (!references.TryGetValue(dependency, out HashSet<string> referrers))
                    {
                        referrers = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                        references.Add(dependency, referrers);
                    }
                    referrers.Add(pair.Key);
                }
            }

            _directReferences = references.ToDictionary(
                pair => pair.Key,
                pair => pair.Value.OrderBy(path => path, StringComparer.OrdinalIgnoreCase).ToArray(),
                StringComparer.OrdinalIgnoreCase);
        }

        public IReadOnlyList<string> GetDirectReferences(string targetPath)
        {
            return GetReferences(new[] { targetPath }, false);
        }

        public IReadOnlyList<string> GetReferences(IEnumerable<string> targetPaths, bool recursive)
        {
            var targets = new HashSet<string>(
                targetPaths.Where(path => !string.IsNullOrEmpty(path)),
                StringComparer.OrdinalIgnoreCase);
            var references = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var pending = new Queue<string>(targets);
            var traversed = new HashSet<string>(targets, StringComparer.OrdinalIgnoreCase);

            while (pending.Count > 0)
            {
                string current = pending.Dequeue();
                if (!_directReferences.TryGetValue(current, out string[] directReferences))
                {
                    continue;
                }

                foreach (string reference in directReferences)
                {
                    if (targets.Contains(reference))
                    {
                        continue;
                    }

                    references.Add(reference);
                    if (recursive && traversed.Add(reference))
                    {
                        pending.Enqueue(reference);
                    }
                }
            }

            return references.OrderBy(path => path, StringComparer.OrdinalIgnoreCase).ToArray();
        }
    }
}
