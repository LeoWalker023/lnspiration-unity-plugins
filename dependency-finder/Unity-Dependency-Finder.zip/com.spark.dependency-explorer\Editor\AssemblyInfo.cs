using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Spark.DependencyExplorer.Editor.Tests")]
