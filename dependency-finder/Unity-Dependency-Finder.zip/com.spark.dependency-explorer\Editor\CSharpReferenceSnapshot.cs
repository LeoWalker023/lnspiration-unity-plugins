using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace Spark.DependencyExplorer
{
    internal sealed class CSharpReferenceSnapshot
    {
        private readonly ReverseReferenceGraph _referenceGraph;

        private CSharpReferenceSnapshot(ReverseReferenceGraph referenceGraph)
        {
            _referenceGraph = referenceGraph;
        }

        public IReadOnlyList<string> GetReferences(IEnumerable<string> targetPaths, bool recursive)
        {
            return _referenceGraph.GetReferences(targetPaths, recursive);
        }

        public static CSharpReferenceSnapshot Capture(
            IEnumerable<string> additionalTargetPaths,
            CancelableProgress progress = null)
        {
            string[] scriptPaths = AssetDatabase.FindAssets("t:MonoScript", new[] { "Assets" })
                .Select(AssetDatabase.GUIDToAssetPath)
                .Select(AssetPathUtility.Normalize)
                .Where(path => path.EndsWith(".cs", StringComparison.OrdinalIgnoreCase))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderBy(path => path, StringComparer.OrdinalIgnoreCase)
                .ToArray();
            string[] symbolPaths = scriptPaths
                .Concat(additionalTargetPaths ?? Array.Empty<string>())
                .Where(path => path.EndsWith(".cs", StringComparison.OrdinalIgnoreCase))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToArray();
            var symbols = new Dictionary<string, HashSet<string>>(StringComparer.Ordinal);

            foreach (string scriptPath in symbolPaths)
            {
                AddSymbol(symbols, Path.GetFileNameWithoutExtension(scriptPath), scriptPath);
                MonoScript script = AssetDatabase.LoadAssetAtPath<MonoScript>(scriptPath);
                Type scriptType = script == null ? null : script.GetClass();
                if (scriptType != null)
                {
                    AddSymbol(symbols, scriptType.Name, scriptPath);
                }
            }

            string projectRoot = Directory.GetParent(Application.dataPath).FullName;
            var directDependencies = new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < scriptPaths.Length; i++)
            {
                string sourcePath = scriptPaths[i];
                if (progress != null && progress(new ScanProgress(
                        "正在建立代码引用索引",
                        sourcePath,
                        scriptPaths.Length == 0 ? 1f : (float)i / scriptPaths.Length)))
                {
                    throw new OperationCanceledException("代码引用索引已取消。");
                }

                var dependencies = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                try
                {
                    string absolutePath = Path.Combine(projectRoot, sourcePath.Replace('/', Path.DirectorySeparatorChar));
                    string source = File.ReadAllText(absolutePath);
                    foreach (string identifier in CSharpIdentifierScanner.ExtractIdentifiers(source))
                    {
                        if (!symbols.TryGetValue(identifier, out HashSet<string> referencedScripts))
                        {
                            continue;
                        }

                        foreach (string referencedScript in referencedScripts)
                        {
                            if (!referencedScript.Equals(sourcePath, StringComparison.OrdinalIgnoreCase))
                            {
                                dependencies.Add(referencedScript);
                            }
                        }
                    }
                }
                catch (IOException)
                {
                    // A script can move while the index is being built; skip that file and keep the rest usable.
                }
                catch (UnauthorizedAccessException)
                {
                    // Read-only or transiently locked files do not invalidate the rest of the index.
                }

                directDependencies[sourcePath] = dependencies.ToArray();
            }

            progress?.Invoke(new ScanProgress("正在建立代码引用索引", "索引完成", 1f));
            return new CSharpReferenceSnapshot(new ReverseReferenceGraph(directDependencies));
        }

        private static void AddSymbol(
            IDictionary<string, HashSet<string>> symbols,
            string symbol,
            string scriptPath)
        {
            if (string.IsNullOrEmpty(symbol))
            {
                return;
            }

            if (!symbols.TryGetValue(symbol, out HashSet<string> paths))
            {
                paths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                symbols.Add(symbol, paths);
            }
            paths.Add(scriptPath);
        }
    }

    internal static class CSharpIdentifierScanner
    {
        public static IReadOnlyCollection<string> ExtractIdentifiers(string source)
        {
            var identifiers = new HashSet<string>(StringComparer.Ordinal);
            if (string.IsNullOrEmpty(source))
            {
                return identifiers;
            }

            int index = 0;
            while (index < source.Length)
            {
                if (TrySkipComment(source, ref index) || TrySkipLiteral(source, ref index))
                {
                    continue;
                }

                if (!IsIdentifierStart(source[index]))
                {
                    index++;
                    continue;
                }

                int start = index++;
                while (index < source.Length && IsIdentifierPart(source[index]))
                {
                    index++;
                }
                identifiers.Add(source.Substring(start, index - start));
            }

            return identifiers;
        }

        private static bool TrySkipComment(string source, ref int index)
        {
            if (source[index] != '/' || index + 1 >= source.Length)
            {
                return false;
            }

            if (source[index + 1] == '/')
            {
                index += 2;
                while (index < source.Length && source[index] != '\n')
                {
                    index++;
                }
                return true;
            }

            if (source[index + 1] == '*')
            {
                index += 2;
                while (index + 1 < source.Length && (source[index] != '*' || source[index + 1] != '/'))
                {
                    index++;
                }
                index = Math.Min(source.Length, index + 2);
                return true;
            }

            return false;
        }

        private static bool TrySkipLiteral(string source, ref int index)
        {
            int quoteIndex = index;
            bool verbatim = false;
            if (source[index] == '@' && index + 1 < source.Length && source[index + 1] == '"')
            {
                verbatim = true;
                quoteIndex = index + 1;
            }
            else if (source[index] == '$' && index + 1 < source.Length)
            {
                if (source[index + 1] == '"')
                {
                    quoteIndex = index + 1;
                }
                else if (index + 2 < source.Length && source[index + 1] == '@' && source[index + 2] == '"')
                {
                    verbatim = true;
                    quoteIndex = index + 2;
                }
                else
                {
                    return false;
                }
            }
            else if (source[index] == '@'
                && index + 2 < source.Length
                && source[index + 1] == '$'
                && source[index + 2] == '"')
            {
                verbatim = true;
                quoteIndex = index + 2;
            }
            else if (source[index] != '"' && source[index] != '\'')
            {
                return false;
            }

            char quote = source[quoteIndex];
            index = quoteIndex + 1;
            while (index < source.Length)
            {
                if (verbatim && quote == '"' && source[index] == '"')
                {
                    if (index + 1 < source.Length && source[index + 1] == '"')
                    {
                        index += 2;
                        continue;
                    }
                    index++;
                    break;
                }

                if (!verbatim && source[index] == '\\')
                {
                    index = Math.Min(source.Length, index + 2);
                    continue;
                }

                if (source[index] == quote)
                {
                    index++;
                    break;
                }
                index++;
            }
            return true;
        }

        private static bool IsIdentifierStart(char value)
        {
            return value == '_' || char.IsLetter(value);
        }

        private static bool IsIdentifierPart(char value)
        {
            return value == '_' || char.IsLetterOrDigit(value);
        }
    }
}
