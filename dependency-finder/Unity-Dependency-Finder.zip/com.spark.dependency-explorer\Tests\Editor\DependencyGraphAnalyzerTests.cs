using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace Spark.DependencyExplorer.Tests
{
    internal sealed class DependencyGraphAnalyzerTests
    {
        [Test]
        public void FindSharedDependencies_ProtectsAnExternalReferenceAndItsDependencyChain()
        {
            var graph = new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase)
            {
                ["Assets/Outside.prefab"] = new[] { "Assets/Shared.mat" },
                ["Assets/Shared.mat"] = new[] { "Assets/Shared.png" },
                ["Assets/Shared.png"] = Array.Empty<string>(),
                ["Assets/Selected.prefab"] = new[] { "Assets/Shared.mat" }
            };

            var shared = DependencyGraphAnalyzer.FindSharedDependencies(
                new[] { "Assets/Shared.mat", "Assets/Shared.png" },
                new[] { "Assets/Selected.prefab" },
                graph.Keys,
                path => graph[path]);

            Assert.That(shared, Is.EquivalentTo(new[] { "Assets/Shared.mat", "Assets/Shared.png" }));
        }

        [Test]
        public void FindSharedDependencies_DoesNotTreatSelectedSourcesAsExternalUsers()
        {
            var graph = new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase)
            {
                ["Assets/Selected.prefab"] = new[] { "Assets/OnlyUsedHere.mat" },
                ["Assets/OnlyUsedHere.mat"] = Array.Empty<string>(),
                ["Assets/Unrelated.asset"] = Array.Empty<string>()
            };

            var shared = DependencyGraphAnalyzer.FindSharedDependencies(
                new[] { "Assets/OnlyUsedHere.mat" },
                new[] { "Assets/Selected.prefab" },
                graph.Keys,
                path => graph[path]);

            Assert.That(shared, Is.Empty);
        }
    }
}
