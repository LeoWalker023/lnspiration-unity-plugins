# Changelog

## 1.1.0 - 2026-08-11

- Added a forward dependency / reverse reference switch without changing the approved two-pane layout.
- Added direct and recursive reverse lookup for assets under `Assets`, including folder inputs.
- Added code-to-code candidate lookup based on C# type identifiers while ignoring comments and literals.
- Added direct, indirect, and code-reference badges plus input-scope location badges.
- Kept reverse results read-only so they can never enter synchronized dependency deletion.
- Reused explicit Material texture and Shader extraction in the reverse project index.
- Added EditMode coverage for reverse graph traversal, Material-to-texture reverse lookup, and C# identifier scanning.

## 1.0.4 - 2026-08-11

- Added Up/Down keyboard navigation for the active source asset.
- Navigation follows the currently visible hierarchy and skips collapsed or filtered rows.
- Automatically scrolls the source list to keep the keyboard-selected row visible.
- Added EditMode coverage for navigation order and list boundaries.

## 1.0.3 - 2026-08-10

- Rebuilt the Editor window styling to match the approved interactive design.
- Added a dedicated header, import surface, two-pane work area, asset chips, fixed deletion footer, and full hover/selection states.
- Replaced default Unity controls with consistent custom buttons, segmented controls, checkboxes, badges, spacing, and typography.
- Kept image-only thumbnails in the reference list while preserving compact rows for other asset types.
- Improved footer and filter ergonomics by making option labels clickable.

## 1.0.2 - 2026-08-10

- Added drag-and-drop scanning for individual assets as well as folders.
- Rebuilt the window as a Chinese two-pane source and reference browser.
- Added per-asset source deletion selection and optional per-reference deletion selection.
- Added Project-window location actions throughout the source and reference lists.
- Added 44-pixel thumbnails for image references while preserving compact rows for other asset types.
- Added a reusable project dependency snapshot for shared-reference protection.
- Added EditMode coverage for individual asset scans and granular deletion plans.

## 1.0.1 - 2026-08-10

- Added explicit Material texture and Shader dependency collection.
- Expanded Material rows automatically and made source rows toggle their dependency list.
- Added expand-all and collapse-all controls.
- Localized the complete Editor interface to Chinese.

## 1.0.0 - 2026-08-10

- Added folder drag-and-drop and automatic dependency scanning.
- Added direct and recursive dependency views, path search, and external-only filtering.
- Added folder deletion with optional dependency cleanup.
- Added shared dependency, code asset, package, and built-in resource protection.
- Added EditMode tests for scanning and deletion safety, plus Chinese usage documentation.
