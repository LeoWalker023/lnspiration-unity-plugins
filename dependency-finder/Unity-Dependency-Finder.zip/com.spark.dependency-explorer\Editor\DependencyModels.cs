using System;
using System.Collections.Generic;

namespace Spark.DependencyExplorer
{
    internal enum ReferenceRelationKind
    {
        Direct,
        Indirect,
        Code
    }

    internal readonly struct ReferenceDisplayItem
    {
        public ReferenceDisplayItem(string assetPath, ReferenceRelationKind relationKind)
        {
            AssetPath = assetPath;
            RelationKind = relationKind;
        }

        public string AssetPath { get; }
        public ReferenceRelationKind RelationKind { get; }
    }

    internal sealed class AssetDependencyRecord
    {
        public AssetDependencyRecord(
            string assetPath,
            IReadOnlyList<string> directDependencies,
            IReadOnlyList<string> recursiveDependencies)
        {
            AssetPath = assetPath;
            DirectDependencies = directDependencies;
            RecursiveDependencies = recursiveDependencies;
        }

        public string AssetPath { get; }
        public IReadOnlyList<string> DirectDependencies { get; }
        public IReadOnlyList<string> RecursiveDependencies { get; }
    }

    internal sealed class DependencyScanResult
    {
        public DependencyScanResult(
            IReadOnlyList<string> inputPaths,
            IReadOnlyList<AssetDependencyRecord> records,
            IReadOnlyList<string> uniqueDependencies,
            IReadOnlyList<string> errors)
        {
            InputPaths = inputPaths;
            Records = records;
            UniqueDependencies = uniqueDependencies;
            Errors = errors;
        }

        public IReadOnlyList<string> InputPaths { get; }
        public IReadOnlyList<AssetDependencyRecord> Records { get; }
        public IReadOnlyList<string> UniqueDependencies { get; }
        public IReadOnlyList<string> Errors { get; }
    }

    internal sealed class DeletionPlan
    {
        public DeletionPlan(
            IReadOnlyList<string> sourceAssets,
            IReadOnlyList<string> dependencyAssets,
            IReadOnlyList<string> sharedDependencies,
            IReadOnlyList<string> protectedCodeDependencies,
            IReadOnlyList<string> nonProjectDependencies,
            bool cancelled)
        {
            SourceAssets = sourceAssets;
            DependencyAssets = dependencyAssets;
            SharedDependencies = sharedDependencies;
            ProtectedCodeDependencies = protectedCodeDependencies;
            NonProjectDependencies = nonProjectDependencies;
            Cancelled = cancelled;
        }

        public IReadOnlyList<string> SourceAssets { get; }
        public IReadOnlyList<string> DependencyAssets { get; }
        public IReadOnlyList<string> SharedDependencies { get; }
        public IReadOnlyList<string> ProtectedCodeDependencies { get; }
        public IReadOnlyList<string> NonProjectDependencies { get; }
        public bool Cancelled { get; }
    }

    internal sealed class AssetDeletionResult
    {
        public AssetDeletionResult(
            IReadOnlyList<string> failures,
            IReadOnlyList<string> skippedDependencyAssets)
        {
            Failures = failures;
            SkippedDependencyAssets = skippedDependencyAssets;
        }

        public IReadOnlyList<string> Failures { get; }
        public IReadOnlyList<string> SkippedDependencyAssets { get; }
    }

    internal readonly struct ScanProgress
    {
        public ScanProgress(string title, string detail, float progress)
        {
            Title = title;
            Detail = detail;
            Progress = progress;
        }

        public string Title { get; }
        public string Detail { get; }
        public float Progress { get; }
    }

    internal delegate bool CancelableProgress(ScanProgress progress);
}
