using System.Collections.Generic;
using System.Linq;
using UnityEditor;

namespace Spark.DependencyExplorer
{
    internal static class AssetDeletionService
    {
        public static AssetDeletionResult MoveToTrash(DeletionPlan plan)
        {
            var failures = new List<string>();

            foreach (string sourceAsset in plan.SourceAssets)
            {
                if (!AssetDatabase.MoveAssetToTrash(sourceAsset))
                {
                    failures.Add(sourceAsset);
                }
            }

            if (failures.Count > 0)
            {
                AssetDatabase.Refresh();
                return new AssetDeletionResult(failures, plan.DependencyAssets.ToArray());
            }

            foreach (string dependency in plan.DependencyAssets)
            {
                if (!AssetDatabase.MoveAssetToTrash(dependency))
                {
                    failures.Add(dependency);
                }
            }

            AssetDatabase.Refresh();
            return new AssetDeletionResult(failures, new string[0]);
        }
    }
}
